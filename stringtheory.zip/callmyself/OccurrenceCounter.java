package callmyself;

/**
 * 📚 OccurrenceCounter.java
 *
 * This class provides a method to count the number of occurrences of a specific element in an integer array.
 * The method uses recursion to traverse the array from the given index to the end. 🚀
 *
 * 💡 Key Concepts:
 * - Recursion: The method calls itself while incrementing the index.
 * - Base Case: Stops recursion when the index is out of array bounds.
 * - Edge Case Handling: Returns 0 if the array is null or empty.
 */

public class OccurrenceCounter {

    /**
     * Counts the occurrences of a specific element in an integer array.
     *
     * @param arr - The array of integers where the search is performed.
     * @param element - The element whose occurrences are to be counted.
     * @param index - The current index in the array to be checked.
     * @return - The number of times the element appears in the array from the given index onward.
     *           Returns 0 if the array is null, empty, or the index is out of bounds.
     */
    public int countOccurrences(int[] arr, int element, int index) {

        // Edge cases: null array, empty array, or invalid index
        if (arr == null || arr.length == 0 || index < 0 || index >= arr.length) {
            return 0;
        }

        // Check if the current element matches the target
        int count = (arr[index] == element) ? 1 : 0;

        // Recursively call the method with the next index and accumulate the count
        return count + countOccurrences(arr, element, index + 1);
    }
}
