# 📚 Miscellaneous Tasks

## 📝 Description:

This folder contains a collection of smaller tasks and utility programs developed during the Selection Sprint at kood/Jõhvi. These programs serve as exercises to practice various coding concepts and problem-solving techniques. 🚀

---

## 💡 Skills Acquired:

* Practicing basic and intermediate programming tasks.
* Applying core Java concepts in diverse scenarios.
* Enhancing logical thinking and algorithmic skills.
* Developing small, self-contained utility programs.

---

## 📂 Program List and Features:

1. **FizzBuzz:**

   * Prints numbers from 1 to 100.
   * Replaces multiples of 3 with "Fizz", multiples of 5 with "Buzz", and multiples of both with "FizzBuzz".

2. **Factorial Calculator:**

   * Calculates the factorial of a given number.
   * Uses recursive or iterative approaches.

3. **Number Reverser:**

   * Reverses the digits of a given integer.
   * Demonstrates loop-based digit extraction.

4. **Temperature Converter:**

   * Converts temperatures between Celsius and Fahrenheit.
   * Uses basic arithmetic for conversion.

5. **Triangle Validator:**

   * Checks if three given side lengths form a valid triangle.
   * Uses the triangle inequality theorem.

---

## 🚀 How to Run:

1. Open a terminal in the Miscellaneous Tasks directory.
2. Compile the desired Java file:

   ```bash
   javac FileName.java
   ```
3. Run the compiled file:

   ```bash
   java FileName
   ```

### Usage Example:

```bash
javac FizzBuzz.java
java FizzBuzz
```

---

## 🗝️ Key Concepts Covered:

* Arithmetic Operations: Addition, subtraction, multiplication, division
* Logical Validation: Implementing basic checks and conditions
* Looping Techniques: Iterative calculations and sequence generation
* Utility Programming: Small tools for daily tasks

Happy Coding! 😊🚀
