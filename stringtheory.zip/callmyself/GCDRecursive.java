package callmyself;

/**
 * 📚 GCDRecursive.java
 *
 * This class provides a method to calculate the Greatest Common Divisor (GCD) of two integers using recursion.
 * The GCD of two numbers is the largest positive integer that divides both numbers without leaving a remainder.
 * The method implements the **Euclidean algorithm**, which is efficient for finding the GCD. 🚀
 *
 * 💡 Key Concepts:
 * - Recursion: The method calls itself with updated values.
 * - Euclidean Algorithm: Uses the property GCD(a, b) = GCD(b, a % b).
 * - Edge Case Handling: Returns 0 if both numbers are zero.
 * - Absolute Values: Handles negative inputs correctly using Math.abs().
 */

public class GCDRecursive {

    /**
     * Calculates the Greatest Common Divisor (GCD) of two integers.
     *
     * @param a - The first integer.
     * @param b - The second integer.
     * @return - The GCD of a and b.
     *           Returns 0 if both numbers are zero (undefined case).
     *           Returns the absolute value of a if b is zero.
     */
    public int gcd(int a, int b) {

        // Edge case: if both numbers are zero, GCD is undefined (return 0)
        if (a == 0 && b == 0) return 0;

        // Base case: if the second number is zero, return the absolute value of the first number
        if (b == 0) return Math.abs(a);

        // Recursive call: GCD(b, a % b) using the Euclidean algorithm
        return gcd(b, a % b);
    }
}
