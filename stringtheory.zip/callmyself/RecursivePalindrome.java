package callmyself;

/**
 * 📚 RecursivePalindrome.java
 *
 * This class checks whether a given string is a palindrome.
 * A palindrome is a word, phrase, or number that reads the same backward as forward.
 * The method uses recursion to compare characters from both ends of the cleaned string. 🚀
 *
 * 💡 Key Concepts:
 * - Recursion: The method calls itself to compare characters from both ends.
 * - String Cleaning: Removes non-alphanumeric characters and converts to lowercase.
 * - Base Case: Stops recursion when start index meets or exceeds end index.
 * - Edge Case Handling: Returns false if the input string is null.
 */

public class RecursivePalindrome {

    /**
     * Public method to check if the given string is a palindrome.
     *
     * @param str - The input string to check.
     * @return - True if the string is a palindrome, false otherwise.
     */
    public boolean isPalindrome(String str) {

        // Edge case: Return false if the input string is null
        if (str == null) return false;

        // Preprocess the string: remove non-alphanumeric characters and convert to lowercase
        str = str.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();

        // Base case: if the cleaned string has length 0 or 1, it's a palindrome
        if (str.length() <= 1) return true;

        // Start the recursive palindrome check from both ends
        return isPalindromeHelper(str, 0, str.length() - 1);
    }

    /**
     * Private recursive method to check palindrome property.
     *
     * @param str - The cleaned input string.
     * @param start - The starting index for comparison.
     * @param end - The ending index for comparison.
     * @return - True if the substring between start and end is a palindrome, false otherwise.
     */
    private boolean isPalindromeHelper(String str, int start, int end) {

        // Base case: if the start index meets or exceeds the end index, it's a palindrome
        if (start >= end) return true;

        // If characters at the current positions do not match, it's not a palindrome
        if (str.charAt(start) != str.charAt(end)) return false;

        // Recursive call: move towards the center by updating indices
        return isPalindromeHelper(str, start + 1, end - 1);
    }
}
