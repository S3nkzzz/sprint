package callmyself;



/**
 * 📚 Fibonacci.java
 *
 * This class provides a method to calculate the Fibonacci number for a given non-negative integer.
 * The Fibonacci sequence is defined as follows:
 * - F(0) = 0
 * - F(1) = 1
 * - F(n) = F(n-1) + F(n-2) for n > 1
 *
 * The method uses recursion to calculate the Fibonacci value. 🚀
 *
 * 💡 Key Concepts:
 * - Recursion: The method calls itself with decremented values.
 * - Base Cases: Handles the initial values (0 and 1) directly.
 * - Edge Case Handling: Returns -1 for negative input as Fibonacci is not defined for negative numbers.
 */

public class Fibonacci {

    /**
     * Calculates the nth Fibonacci number using recursion.
     *
     * @param n - The non-negative integer for which the Fibonacci number is to be calculated.
     * @return - The Fibonacci number at position n.
     *           Returns 0 if n is 0 (base case).
     *           Returns 1 if n is 1 (base case).
     *           Returns -1 if n is negative, as Fibonacci is not defined for negative numbers.
     */
    public int calculateFibonacci(int n) {

        // Edge case: if n is negative, return -1 as Fibonacci is not defined
        if (n < 0) return -1;

        // Base cases: directly return the value for n = 0 or n = 1
        if (n == 0) return 0;
        if (n == 1) return 1;

        // Recursive call: sum of the previous two Fibonacci numbers
        return calculateFibonacci(n - 1) + calculateFibonacci(n - 2);
    }
}
