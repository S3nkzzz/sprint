package callmyself;



/**
 * 📚 Chunks.java
 *
 * This class implements a binary search algorithm to find a target element in a sorted integer array.
 * The method not only returns whether the element exists, but also counts the number of steps taken to find it. 🚀
 *
 * 💡 Key Concepts:
 * - Binary Search: Efficiently finding elements in sorted arrays.
 * - Recursion: Calling the method itself with updated parameters.
 * - Edge Case Handling: Null or empty arrays.
 * - Optimization: Using the left midpoint in even-sized arrays to balance search.
 */

public class Chunks {

    /**
     * Main search method to find the target element in the array.
     *
     * @param sortedArray - An array of integers that is sorted in ascending order.
     * @param target - The integer value to find within the array.
     * @return - The number of steps taken to find the target or 0 if not found.
     */
    public static int search(int[] sortedArray, int target) {
        // Check if the array is null or empty
        if (sortedArray == null || sortedArray.length == 0) {
            return 0;
        }
        // Start the binary search with initial boundaries and step count
        return binarySearch(sortedArray, target, 0, sortedArray.length - 1, 0);
    }

    /**
     * Private method implementing binary search recursively.
     *
     * @param arr - The array being searched.
     * @param target - The value to find.
     * @param low - The starting index for the search range.
     * @param high - The ending index for the search range.
     * @param steps - The number of steps taken so far.
     * @return - The number of steps if the target is found, or continues recursively.
     */
    private static int binarySearch(int[] arr, int target, int low, int high, int steps) {
        // Base case: if search range is invalid, return step count
        if (low > high) {
            return steps;
        }

        // Calculate midpoint (prefer left middle if even)
        int mid = (low + high) / 2;
        if ((high - low + 1) % 2 == 0) {
            mid = (low + high - 1) / 2;
        }

        // Increment step count
        steps++;

        // Check if the midpoint element matches the target
        if (arr[mid] == target) {
            return steps;
        }
        // Recursively search the left half if target is smaller
        else if (target < arr[mid]) {
            return binarySearch(arr, target, low, mid - 1, steps);
        }
        // Recursively search the right half if target is larger
        else {
            return binarySearch(arr, target, mid + 1, high, steps);
        }
    }
}
