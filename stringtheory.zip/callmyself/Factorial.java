package callmyself;
/**
 * 📚 Factorial.java
 *
 * This class provides a method to calculate the factorial of a given non-negative integer.
 * The factorial of a number (n!) is the product of all positive integers from 1 to n.
 * The method uses recursion to calculate the factorial value. 🚀
 *
 * 💡 Key Concepts:
 * - Recursion: The method calls itself with a decremented value.
 * - Base Case: Stops recursion when n is 0 or 1.
 * - Edge Case Handling: Returns 0 for negative input as factorial is undefined for negative numbers.
 */

public class Factorial {

    /**
     * Calculates the factorial of a given non-negative integer.
     *
     * @param n - The non-negative integer for which the factorial is to be calculated.
     * @return - The factorial of the given number.
     *           Returns 1 if n is 0 or 1 (base case).
     *           Returns 0 if n is negative, as factorial is undefined.
     */
    public int calculateFactorial(int n) {

        // Edge case: if n is negative, return 0 as factorial is not defined
        if (n < 0) return 0;

        // Base case: factorial of 0 or 1 is 1
        if (n == 0 || n == 1) return 1;

        // Recursive call: n * factorial of (n - 1)
        return n * calculateFactorial(n - 1);
    }
}
