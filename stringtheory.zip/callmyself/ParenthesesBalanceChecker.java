package callmyself;

/**
 * 📚 ParenthesesBalanceChecker.java
 *
 * This class checks whether a given string has balanced parentheses.
 * A string is considered balanced if every opening parenthesis '(' has a corresponding closing parenthesis ')',
 * and the parentheses are correctly nested.
 *
 * 💡 Key Concepts:
 * - Recursion: The method calls itself to check the next character.
 * - Balance Counter: Increments for '(' and decrements for ')'.
 * - Edge Case Handling: Returns false if the string is null or if at any point balance becomes negative.
 */

public class ParenthesesBalanceChecker {

    /**
     * Public method to check if the parentheses in a given string are balanced.
     *
     * @param str - The input string to check.
     * @return - True if the parentheses are balanced, false otherwise.
     */
    public boolean isBalanced(String str) {

        // Edge case: Return false if the input string is null
        if (str == null) return false;

        // Start the recursive check from index 0 with initial balance 0
        return checkBalance(str, 0, 0);
    }

    /**
     * Private recursive method to check balance of parentheses.
     *
     * @param str - The input string being checked.
     * @param index - The current character index being examined.
     * @param balance - The current balance count (number of open '(' minus closed ')').
     * @return - True if the balance is maintained throughout, false otherwise.
     */
    private boolean checkBalance(String str, int index, int balance) {

        // If balance is negative at any point, parentheses are unbalanced
        if (balance < 0) return false;

        // Base case: If we reached the end of the string, check if balance is zero
        if (index == str.length()) return balance == 0;

        // Get the current character from the string
        char c = str.charAt(index);

        // If the character is '(', increase balance
        if (c == '(') {
            return checkBalance(str, index + 1, balance + 1);
        }
        // If the character is ')', decrease balance
        else if (c == ')') {
            return checkBalance(str, index + 1, balance - 1);
        }
        // If it's any other character, just move to the next one without changing balance
        else {
            return checkBalance(str, index + 1, balance);
        }
    }
}
