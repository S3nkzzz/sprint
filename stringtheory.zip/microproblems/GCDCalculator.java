package microproblems;

/**
 * 📚 GCDCalculator.java
 * 
 * This class provides a method to calculate the Greatest Common Divisor (GCD) of two integers.
 * The method uses the Euclidean algorithm, which efficiently finds the GCD through iterative division.
 * 
 * 💡 Key Concepts:
 * - Euclidean Algorithm: A mathematical method to find the GCD.
 * - Iterative Approach: Using a while loop to perform successive divisions.
 * - Absolute Value: Ensuring the GCD is always positive, regardless of input sign.
 */

public class GCDCalculator {

    /**
     * Calculates the Greatest Common Divisor (GCD) of two integers using the Euclidean algorithm.
     * 
     * @param a - The first integer.
     * @param b - The second integer.
     * @return - The absolute value of the GCD of the two numbers.
     */
    public int gcd(int a, int b) {

        // Step 1: Continue until the remainder becomes zero.
        while (b != 0) {
            int temp = b;     // Store the current value of b.
            b = a % b;        // Update b to the remainder of a divided by b.
            a = temp;         // Set a to the previous value of b.
        }

        // Step 2: Return the absolute value of a, which now contains the GCD.
        return Math.abs(a);
    }
}
