package microproblems;

/**
 * 📚 PowerCalculator.java
 * 
 * This class provides a method to calculate the power of a number (base^exponent).
 * The method uses a simple iterative approach to multiply the base by itself
 * the specified number of times.
 * 
 * 💡 Key Concepts:
 * - Power Calculation: Raising a base to a positive exponent.
 * - Iterative Multiplication: Using a for loop to calculate the result.
 * - Edge Case Handling: Properly handles zero exponent.
 */

public class PowerCalculator {

    /**
     * Calculates the power of a given base raised to a specified exponent.
     * 
     * @param base - The base number to be raised.
     * @param exponent - The exponent to which the base is raised.
     * @return - The calculated power of the base, or 1 if the exponent is 0.
     */
    public int calculatePower(int base, int exponent) {

        // Step 1: Edge case: Any number raised to the power of 0 is 1.
        if (exponent == 0) {
            return 1;
        }

        // Step 2: Initialize the result with the base value.
        int result = base;

        // Step 3: Multiply the base by itself (exponent - 1) times.
        for (int i = 2; i <= exponent; i++) {
            result = result * base; // Multiply the current result by the base.
        }

        // Step 4: Return the calculated power.
        return result;
    }
}
