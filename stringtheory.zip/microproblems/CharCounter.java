package microproblems;

/**
 * 📚 CharCounter.java
 * 
 * This class provides a method to count the occurrences of a specified character
 * within a given string, ignoring case sensitivity.
 * 
 * 💡 Key Concepts:
 * - Character Counting: Iterating through each character in the string.
 * - Case Insensitivity: Converting both the input character and target to lowercase.
 * - Efficiency: Uses a simple loop to count matches.
 */

public class CharCounter {

    /**
     * Counts the occurrences of a specified character in a given string, ignoring case.
     * 
     * @param input - The input string in which to count the occurrences.
     * @param target - The character to count.
     * @return - The number of occurrences of the target character.
     */
    public int countOccurrences(String input, char target) {
        int count = 0; // Initialize the count to zero.

        // Step 1: Loop through each character in the input string.
        for (int i = 0; i < input.length(); i++) {
            // Step 2: Compare characters in a case-insensitive way.
            if (Character.toLowerCase(input.charAt(i)) == Character.toLowerCase(target)) {
                count++; // Increment the count if characters match.
            }
        }

        // Step 3: Return the total count of occurrences.
        return count;
    }
}
