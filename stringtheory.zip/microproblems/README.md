# 📚 Micro Problems

## 📝 Description:

This folder contains small coding challenges that focus on basic problem-solving skills, mathematical computations, and simple logic implementations. These tasks are aimed at strengthening algorithmic thinking and core Java skills. 🚀

---

## 💡 Skills Acquired:

* Basic problem-solving techniques.
* Mathematical computations and number manipulation.
* Simple data validation and logical reasoning.
* Implementing basic algorithms and utility functions.
* Practicing efficient and clean coding.

---

## 📂 Program List and Features:

1. **CharCounter:**

   * Counts occurrences of a specific character in a string.
   * Uses loops and conditional checks.

2. **DigitSum:**

   * Calculates the sum of digits in a number.
   * Demonstrates modulus and division operations.

3. **GCDCalculator:**

   * Finds the Greatest Common Divisor (GCD) of two numbers.
   * Uses the Euclidean algorithm for computation.

4. **PrimeChecker:**

   * Determines whether a number is prime.
   * Uses divisibility rules and loops.

5. **Tree:**

   * Creates a simple text-based tree pattern.
   * Uses nested loops for structured output.

---

## 🚀 How to Run:

1. Open a terminal in the Micro Problems directory.
2. Compile the desired Java file:

   ```bash
   javac FileName.java
   ```
3. Run the compiled file:

   ```bash
   java FileName
   ```

### Usage Example:

```bash
javac CharCounter.java
java CharCounter
```

---

## 🗝️ Key Concepts Covered:

* Basic Arithmetic: Addition, division, modulus
* Loops and Iteration: Counting and pattern generation
* Mathematical Reasoning: Prime number detection and GCD calculation
* Text Processing: Character counting and formatting

Happy Coding! 😊🚀
