package microproblems;

/**
 * 📚 SmallestDivisor.java
 * 
 * This class provides a method to find the smallest positive divisor of a given integer,
 * greater than 1. If the number is prime, the smallest divisor will be the number itself.
 * 
 * 💡 Key Concepts:
 * - Divisibility Check: Using the modulus operator to find divisors.
 * - Efficient Search: Starts checking from 2, as 1 is not considered.
 * - Prime Check: If the number itself is the smallest divisor, it is prime.
 */

public class SmallestDivisor {

    /**
     * Finds the smallest divisor of a given positive integer.
     * 
     * @param number - The integer to find the smallest divisor for.
     * @return - The smallest divisor greater than 1.
     */
    public int smallestDivisor(int number) {

        // Step 1: Start from 2 and check up to the number itself.
        for (int i = 2; i <= number; i++) {
            // Step 2: Check if the current number divides the input number without a remainder.
            if (number % i == 0) {
                return i; // Return the smallest divisor as soon as it is found.
            }
        }

        // Step 3: If no divisor other than the number itself is found, return the number.
        return number;
    }
}
