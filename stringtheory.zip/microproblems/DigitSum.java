package microproblems;

/**
 * 📚 DigitSum.java
 * 
 * This class provides a method to calculate the sum of digits of a given integer.
 * It handles both positive and negative numbers by taking the absolute value.
 * 
 * 💡 Key Concepts:
 * - Digit Extraction: Using modulus operator to get the last digit.
 * - Iterative Summation: Using a while loop to sum the digits.
 * - Absolute Value: Ensuring the calculation works with negative numbers.
 */

public class DigitSum {

    /**
     * Calculates the sum of the digits of a given integer.
     * 
     * @param number - The integer whose digits will be summed.
     * @return - The sum of the digits.
     */
    public static int sumOfDigits(int number) {  
        int sum = 0;  // Initialize sum to zero.

        // Step 1: Take the absolute value to handle negative numbers.
        number = Math.abs(number);

        // Step 2: Extract and sum digits using a while loop.
        while (number > 0) {
            int digit = number % 10;  // Get the last digit.
            sum += digit;             // Add the digit to the sum.
            number = number / 10;     // Remove the last digit from the number.
        }

        // Step 3: Return the calculated sum of digits.
        return sum;
    }
}
