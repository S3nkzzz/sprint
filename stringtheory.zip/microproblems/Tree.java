package microproblems;

/**
 * 📚 Tree.java
 * 
 * This class provides a method to print an ASCII representation of a Christmas tree.
 * The tree consists of branches and a trunk, where the height determines the size and structure.
 * 
 * 💡 Key Concepts:
 * - Looping: Using nested loops to print rows of the tree.
 * - String Repetition: Using " ".repeat() and "*".repeat() for formatting.
 * - Conditional Logic: Adjusting trunk size based on tree height.
 */

public class Tree {

    /**
     * Prints an ASCII representation of a tree based on the specified height.
     * 
     * @param height - The height of the tree (number of rows for the branches).
     */
    public static void tree(int height) {
        
        // Step 1: Handle invalid height input.
        if (height <= 0) {
            return; // Exit the method if the height is zero or negative.
        }

        // Step 2: Print the branches of the tree.
        for (int row = 1; row <= height; row++) {
            int spacing = height - row;        // Calculate leading spaces for alignment.
            int branchSymbols = 2 * row - 1;   // Calculate the number of symbols for the current row.

            // Print the leading spaces.
            System.out.print(" ".repeat(spacing));

            // Print the tree branch.
            if (branchSymbols == 1) {
                // If it's the top of the tree (a single symbol), print "^".
                System.out.println("^");
            } else {
                // Print the left branch, middle stars, and right branch.
                System.out.print("/");                          // Left boundary
                System.out.print("*".repeat(branchSymbols - 2)); // Middle part
                System.out.println("\\");                       // Right boundary
            }
        }

        // Step 3: Determine the trunk dimensions.
        int trunkHeight = Math.max(1, height / 3); // Trunk height is at least 1, proportional to the tree height.
        int trunkWidth;

        // Adjust the trunk width based on the overall height of the tree.
        if (height <= 3) {
            trunkWidth = 1;
        } else if (height <= 6) {
            trunkWidth = 3;
        } else if (height <= 9) {
            trunkWidth = 5;
        } else {
            trunkWidth = 7;
        }

        int trunkSpacing = height - (trunkWidth / 2) - 1; // Calculate the leading spaces for trunk alignment.

        // Step 4: Print the trunk of the tree.
        for (int i = 0; i < trunkHeight; i++) {
            System.out.print(" ".repeat(trunkSpacing)); // Print leading spaces.
            System.out.println("|".repeat(trunkWidth));  // Print the trunk.
        }
    }
}
