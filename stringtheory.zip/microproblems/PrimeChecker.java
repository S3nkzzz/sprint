package microproblems;

/**
 * 📚 PrimeChecker.java
 * 
 * This class provides a method to check if a given integer is a prime number.
 * A prime number is a natural number greater than 1 that has no positive divisors other than 1 and itself.
 * 
 * 💡 Key Concepts:
 * - Prime Number: A number greater than 1 with no divisors other than 1 and itself.
 * - Efficiency: Checking divisors up to the square root of the number.
 * - Early Return: Exiting early if a divisor is found to optimize performance.
 */

public class PrimeChecker {

    /**
     * Checks whether a given integer is a prime number.
     * 
     * @param number - The integer to check for primality.
     * @return - True if the number is prime, false otherwise.
     */
    public static boolean isPrime(int number) {
        
        // Step 1: Early return for numbers less than or equal to 1.
        if (number <= 1) {
            return false; // Numbers less than 2 are not prime.
        }

        // Step 2: Check divisibility from 2 up to the square root of the number.
        for (int i = 2; i <= Math.sqrt(number); i++) {
            // If the number is divisible by any number in this range, it is not prime.
            if (number % i == 0) {
                return false; // Return false immediately when a divisor is found.
            }
        }

        // Step 3: If no divisors are found, the number is prime.
        return true;
    }
}
