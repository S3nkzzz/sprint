package microproblems;

/**
 * 📚 WordCounter.java
 * 
 * This class provides a method to count the number of words in a given sentence.
 * A word is defined as a continuous sequence of alphabetic characters.
 * 
 * 💡 Key Concepts:
 * - Word Counting: Identifying words by checking letter sequences.
 * - Character Check: Using Character.isLetter() to detect alphabetic characters.
 * - State Management: Using a flag to track whether we are inside a word.
 */

public class WordCounter {

    /**
     * Counts the number of words in the given sentence.
     * A word is defined as a continuous sequence of letters.
     * 
     * @param sentence - The input sentence as a string.
     * @return - The number of words found in the sentence.
     */
    public int countWords(String sentence) {
        int count = 0;                // Initialize word counter.
        boolean insideWord = false;   // Track whether we are currently inside a word.

        // Step 1: Iterate through each character in the sentence.
        for (int i = 0; i < sentence.length(); i++) {
            char ch = sentence.charAt(i); // Get the current character.

            // Step 2: Check if the character is a letter.
            if (Character.isLetter(ch)) {
                if (!insideWord) {
                    // If this is the start of a new word, increment the count.
                    insideWord = true;
                    count++; 
                }
            } else {
                // If the character is not a letter, mark the end of the word.
                insideWord = false;
            }
        }

        // Step 3: Return the total word count.
        return count;
    }
}
