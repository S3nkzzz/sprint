package secondgrade;

/**
 * 📚 PositiveEven.java
 * 
 * This class provides a method to check whether a given integer is both positive and even.
 * 
 * 💡 Key Concepts:
 * - Logical Operators: Combining conditions using `&&`.
 * - Modulus Operator: Checking evenness using `n % 2 == 0`.
 * - Simplified Boolean Expression: Directly returning the result of the condition.
 */

public class PositiveEven {

    /**
     * Checks whether the given integer is positive and even.
     * 
     * @param n - The integer to check.
     * @return - True if the number is both positive and even, false otherwise.
     */
    public boolean isPositiveAndEven(int n) {
        // Directly return the result of the combined condition.
        return (n > 0) && (n % 2 == 0);
    }
}
