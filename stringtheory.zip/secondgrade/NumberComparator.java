package secondgrade;

/**
 * 📚 NumberComparator.java
 * 
 * This class provides a method to compare an integer and a floating-point number.
 * The method determines which of the two values is greater or if they are equal.
 * 
 * 💡 Key Concepts:
 * - Type Comparison: Comparing an integer with a double.
 * - Conditional Logic: Using if-else statements to determine the result.
 * - Precision Handling: Works with integer and floating-point numbers.
 */

public class NumberComparator {

    /**
     * Compares an integer and a floating-point number to determine which is greater.
     * 
     * @param n - The integer to compare.
     * @param f - The floating-point number to compare.
     * @return - A string indicating whether the integer is greater, the float is greater, or they are the same.
     */
    public String whichIsGreater(int n, double f) {
        
        // Step 1: Compare the integer and the float.
        if (n > f) {
            return "Integer"; // The integer is greater.
        } else if (n < f) {
            return "Float";   // The floating-point number is greater.
        } else {
            return "Same";    // Both values are equal.
        }
    }
}
