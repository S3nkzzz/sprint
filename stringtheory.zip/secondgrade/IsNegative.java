package secondgrade;

/**
 * 📚 IsNegative.java
 * 
 * This class provides a simple method to check whether a given integer is negative.
 * 
 * 💡 Key Concepts:
 * - Conditional Check: Using the less-than operator to identify negative numbers.
 * - Boolean Return: Returns true if the number is negative, false otherwise.
 */

public class IsNegative {

    /**
     * Checks whether the given integer is negative.
     * 
     * @param n - The integer to check.
     * @return - True if the number is negative, false otherwise.
     */
    public boolean checkIfNegative(int n) {
        // Step 1: Return true if the number is less than 0, otherwise return false.
        return n < 0;
    }
}
