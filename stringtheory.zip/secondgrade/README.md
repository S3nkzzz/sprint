# 📚 Second Grade Java

## 📝 Description:

This folder contains more advanced Java programs developed during the second stage of the Selection Sprint at kood/Jõhvi. These tasks are focused on mastering functions, data processing, and logical problem solving. 🚀

---

## 💡 Skills Acquired:

* Applying advanced functions and methods in Java.
* Performing complex calculations and data manipulations.
* Working with loops and advanced conditional structures.
* Implementing numeric and string-based logic.
* Understanding comparison and validation techniques.
* Handling numeric data effectively.

---

## 📂 Program List and Features:

1. **Accumulator:**

   * Accumulates numbers and calculates the cumulative sum.
   * Demonstrates loop-based addition.

2. **BasicCalc:**

   * A simple calculator that supports addition, subtraction, multiplication, and division.
   * Uses `if-else` structures for operation selection.

3. **NumberComparator:**

   * Compares two integers and prints the result.
   * Demonstrates basic comparison logic.

4. **NumberPrinter:**

   * Prints numbers from a given range.
   * Uses loops to generate the sequence.

5. **PositiveEven:**

   * Identifies positive even numbers in a list.
   * Uses modulo operation for even check.

---

## 🚀 How to Run:

1. Open a terminal in the Second Grade Java directory.
2. Compile the desired Java file:

   ```bash
   javac FileName.java
   ```
3. Run the compiled file:

   ```bash
   java FileName
   ```

### Usage Example:

```bash
javac BasicCalc.java
java BasicCalc
```

---

## 🗝️ Key Concepts Covered:

* Advanced Methods: Calculation and comparison
* Loop Structures: Efficient iteration for processing
* Conditional Logic: Nested `if-else`, `switch-case`
* Numeric Handling: Summing, comparison, and even number detection

Happy Coding! 😊🚀
