package secondgrade;

/**
 * 📚 BetweenLimits.java
 * 
 * This class provides a method to find and return all characters between two given characters (exclusive).
 * The result is returned as a single string containing all characters in between.
 * 
 * 💡 Key Concepts:
 * - Character Range: Finding characters between two given limits.
 * - Swapping Values: Ensuring the lower limit is always smaller.
 * - String Concatenation: Building the result string efficiently.
 */

public class BetweenLimits {

    /**
     * Finds and returns a string containing all characters between the given range.
     * 
     * @param from - The starting character (exclusive).
     * @param to   - The ending character (exclusive).
     * @return     - A string containing all characters between 'from' and 'to'.
     */
    public String findRange(char from, char to) {
        
        // Step 1: Swap the values if 'from' is greater than 'to' to ensure the correct range.
        if (from > to) {
            char temp = from;
            from = to;
            to = temp;
        }

        // Step 2: Initialize an empty result string to store the characters.
        String result = "";

        // Step 3: Iterate from the next character after 'from' up to (but not including) 'to'.
        for (char ch = (char) (from + 1); ch < to; ch++) {
            result += ch;  // Append the current character to the result string.
        }

        // Step 4: Return the constructed string of characters.
        return result;
    }
}
