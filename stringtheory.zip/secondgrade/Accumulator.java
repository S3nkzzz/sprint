package secondgrade;

/**
 * 📚 Accumulator.java
 * 
 * This class provides a method to calculate the sum of all positive integers 
 * from 0 to a given number (n).
 * 
 * 💡 Key Concepts:
 * - Summation: Accumulating values using a loop.
 * - Edge Case Handling: Returning 0 if the input number is negative.
 * - Iterative Approach: Using a for loop to sum numbers.
 */

public class Accumulator {

    /**
     * Calculates the sum of all integers from 0 to n.
     * 
     * @param n - The maximum number to include in the sum.
     * @return - The sum of integers from 0 to n. Returns 0 if n is negative.
     */
    public int accumulate(int n) {
        // Step 1: Handle negative input by returning 0.
        if (n < 0) {
            return 0;
        }

        int sum = 0;  // Initialize the sum to 0.

        // Step 2: Iterate from 0 to n, adding each value to the sum.
        for (int i = 0; i <= n; i++) {
            sum += i;  // Accumulate the current number.
        }

        // Step 3: Return the final sum after the loop completes.
        return sum;
    }
}
