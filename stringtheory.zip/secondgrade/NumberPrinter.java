package secondgrade;

/**
 * 📚 NumberPrinter.java
 * 
 * This class provides a method to print numbers from 0 up to a given positive integer.
 * If the input number is negative, it prints a message indicating that negative numbers are not allowed.
 * 
 * 💡 Key Concepts:
 * - Input Validation: Handling negative numbers gracefully.
 * - Iteration: Using a loop to print numbers sequentially.
 * - User-Friendly Messages: Informing the user when input is invalid.
 */

public class NumberPrinter {

    /**
     * Prints numbers from 0 up to the specified integer.
     * 
     * @param n - The maximum number to print (inclusive).
     *           If the number is negative, prints a warning message.
     */
    public void printNums(int n) {
        
        // Step 1: Check if the input number is negative.
        if (n < 0) {
            System.out.println("Negative numbers are not allowed.");
        } else {
            // Step 2: Use a for loop to print numbers from 0 to n.
            for (int i = 0; i <= n; i++) {
                System.out.println(i);  // Print the current number.
            }
        }
    }
}
