package secondgrade;

/**
 * 📚 Converter.java
 * 
 * This class provides two utility methods for converting between integers and strings:
 * 1. atoi: Converts a numeric string to an integer.
 * 2. itoa: Converts an integer to its string representation.
 * 
 * 💡 Key Concepts:
 * - ASCII Manipulation: Converting characters to numbers.
 * - Edge Case Handling: Dealing with negative numbers and empty strings.
 * - String Building: Efficiently constructing the output string.
 */

public class Converter {

    /**
     * Converts a numeric string to an integer.
     * Mimics the behavior of the C function "atoi".
     * 
     * @param str - The numeric string to convert.
     * @return - The integer representation of the string, or 0 if invalid.
     */
    public int atoi(String str) {
        // Step 1: Handle null or empty input.
        if (str == null || str.equals("")) {
            return 0; // Return 0 for invalid input.
        }

        int result = 0; // Initialize the result.
        int sign = 1;   // Default sign is positive.
        int i = 0;      // Start index for iteration.

        // Step 2: Check if the number is negative.
        if (str.charAt(0) == '-') {
            sign = -1; // Set sign to negative.
            i++;       // Start processing from the next character.
        }

        // Step 3: Process each character of the string.
        for (; i < str.length(); i++) {
            char c = str.charAt(i); // Get the current character.
            
            // Step 3.1: Check if the character is a digit.
            if (c >= '0' && c <= '9') {
                // Accumulate the numeric value.
                result = result * 10 + (c - '0');
            } else {
                // Return 0 for any invalid (non-numeric) character.
                return 0;
            }
        }

        // Step 4: Return the calculated result with the correct sign.
        return result * sign;
    }

    /**
     * Converts an integer to a string.
     * Mimics the behavior of the C function "itoa".
     * 
     * @param num - The integer to convert.
     * @return - The string representation of the integer.
     */
    public String itoa(int num) {
        // Step 1: Handle zero specifically.
        if (num == 0) return "0";

        boolean isNegative = num < 0; // Check if the number is negative.
        if (isNegative) num = -num;   // Convert to positive for processing.

        String result = ""; // Initialize the result as an empty string.

        // Step 2: Process each digit from right to left.
        while (num > 0) {
            int digit = num % 10;                            // Extract the last digit.
            result = (char) ('0' + digit) + result;           // Convert digit to char and prepend.
            num = num / 10;                                   // Remove the last digit.
        }

        // Step 3: Add the negative sign if needed.
        if (isNegative) {
            result = "-" + result;
        }

        // Step 4: Return the final result string.
        return result;
    }
}
