package secondgrade;

/**
 * 📚 BasicCalc.java
 * 
 * This class implements a basic calculator that can perform arithmetic operations
 * (addition, subtraction, multiplication, division, and modulo) based on user input.
 * 
 * 💡 Key Concepts:
 * - Arithmetic Operations: Using operators (+, -, *, /, %).
 * - Input Validation: Preventing division or modulo by zero.
 * - Conditional Logic: Handling different operations using if-else statements.
 */

public class BasicCalc {

    /**
     * Performs a basic arithmetic operation on two integers.
     * 
     * @param a  - The first integer (left operand).
     * @param op - The arithmetic operator ('+', '-', '*', '/', '%').
     * @param b  - The second integer (right operand).
     * @return   - The result of the operation or 0 if the operation is invalid.
     */
    public int doOperation(int a, char op, int b) {

        // Step 1: Check for division or modulo by zero to prevent runtime errors.
        if ((op == '/' || op == '%') && b == 0) {
            return 0; // Return 0 as a safe output for invalid division.
        }

        // Step 2: Perform the operation based on the given operator.
        if (op == '+') {
            return a + b; // Addition
        } 
        else if (op == '-') {
            return a - b; // Subtraction
        } 
        else if (op == '*') {
            return a * b; // Multiplication
        } 
        else if (op == '/') {
            return a / b; // Division
        } 
        else if (op == '%') {
            return a % b; // Modulo
        }

        // Step 3: Return 0 if the operator is not recognized.
        return 0;
    }
}
