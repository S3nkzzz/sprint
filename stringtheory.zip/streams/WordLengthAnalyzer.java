package streams;

import java.util.List;                 // Import List for handling collections
import java.util.Map;                  // Import Map for storing word lengths and counts
import java.util.stream.Collectors;    // Import Collectors for grouping and counting

/**
 * 📚 WordLengthAnalyzer.java
 * 
 * This class provides a method to analyze word lengths in a list.
 * It groups words by their length and counts how many words belong to each length group.
 * 
 * 💡 Key Concepts:
 * - Stream API: Efficient processing and grouping.
 * - Grouping and Counting: Using Collectors for structured data aggregation.
 * - Data Transformation: Converting the count from Long to Integer.
 */

public class WordLengthAnalyzer {

    /**
     * Analyzes the length of words in the given list and returns a map.
     * 
     * @param words - A list of words to analyze.
     * @return - A map where:
     *           - Key: Length of the word.
     *           - Value: Number of words of that length.
     */
    public Map<Integer, Integer> analyzeWordLengths(List<String> words) {
        return words.stream() // Convert the list to a stream
                .collect(Collectors.groupingBy(
                        word -> word.length(),         // Group by word length
                        Collectors.collectingAndThen(
                                Collectors.counting(),  // Count the number of words in each group
                                Long::intValue          // Convert Long count to Integer
                        )
                ));
    }
}
