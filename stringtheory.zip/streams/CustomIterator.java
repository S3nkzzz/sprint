package streams;

import java.util.Iterator;             // Importing the Iterator interface
import java.util.List;                 // Importing the List interface
import java.util.NoSuchElementException; // Importing exception for cases with no more elements

/**
 * 📚 CustomIterator.java
 * 
 * This class implements a custom iterator for a list of integers.
 * It provides methods to traverse the list and access each element one by one.
 * 
 * 💡 Key Concepts:
 * - Iterator Interface: Implementing the methods hasNext() and next().
 * - Handling Edge Cases: Throwing an exception if no more elements are available.
 * - Encapsulation: Storing the list internally and providing controlled access.
 */

public class CustomIterator implements Iterator<Integer> {

    private List<Integer> list; // List of integers to iterate over
    private int index = 0;      // Index to track the current position (starting from 0)

    /**
     * Constructor that initializes the iterator with a list of integers.
     * 
     * @param list - A list of integers to be iterated.
     */
    public CustomIterator(List<Integer> list) {
        this.list = list; // Store the list for internal use
    }

    /**
     * Checks whether there is a next element in the list.
     * 
     * @return - True if there are more elements to iterate, false otherwise.
     */
    @Override
    public boolean hasNext() {
        // Step 1: Check if the current index is within the list size.
        return index < list.size();
    }

    /**
     * Returns the next element in the list.
     * If no more elements are available, it throws a NoSuchElementException.
     * 
     * @return - The next integer in the list.
     * @throws NoSuchElementException - If the list has no more elements.
     */
    @Override
    public Integer next() {
        // Step 2: Check if the next element exists.
        if (!hasNext()) {
            // If no next element, throw an exception.
            throw new NoSuchElementException("No more elements in the list");
        }
        // Step 3: Return the current element and increment the index.
        return list.get(index++);
    }

    /**
     * Returns the entire list of integers.
     * 
     * @return - The list being iterated.
     */
    public List<Integer> getList() {
        return list;
    }
}
