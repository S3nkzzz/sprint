package streams;

import java.util.List;                 // Import List for handling collections
import java.util.stream.Collectors;    // Import Collectors for collecting stream results

/**
 * 📚 StreamPolice.java
 * 
 * This class provides a method to process a list of integers by applying specific filters:
 * - Removes negative numbers.
 * - Removes numbers divisible by 5 but not divisible by 10.
 * 
 * 💡 Key Concepts:
 * - Stream API: Efficient list processing.
 * - Filtering: Removing unwanted numbers based on conditions.
 * - Collectors: Collecting filtered results into a list.
 */

public class StreamPolice {

    /**
     * Processes the given list of integers by applying the following rules:
     * - Removes all negative numbers.
     * - Removes numbers divisible by 5 but not by 10.
     * 
     * @param numbers - A list of integers to process.
     * @return - A new list with only valid numbers.
     */
    public List<Integer> processNumbers(List<Integer> numbers) {
        // Use Stream API to filter the list
        return numbers.stream()
            .filter(n -> n >= 0) // Step 1: Remove negative numbers
            .filter(n -> !(n % 5 == 0 && n % 10 != 0)) // Step 2: Remove numbers divisible by 5 but not by 10
            .collect(Collectors.toList()); // Step 3: Collect the filtered numbers into a list
    }
}
