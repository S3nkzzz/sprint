package streams;

import java.util.List;  // Importing List for handling collections

/**
 * 📚 UsernameProcessor.java
 * 
 * This class provides a method to find the first username from a list.
 * If the list is empty, it returns the default username "Anonymous".
 * 
 * 💡 Key Concepts:
 * - Stream API: Efficient processing of lists.
 * - Optional Handling: Providing a default value when the list is empty.
 * - Functional Approach: Using streams to simplify list processing.
 */

public class UsernameProcessor {

    /**
     * Finds the first username in the list.
     * 
     * @param usernames - A list of usernames.
     * @return - The first username from the list or "Anonymous" if the list is empty.
     */
    public String findFirstUsername(List<String> usernames) {
        // Step 1: Stream the list and find the first element.
        // Step 2: Use orElse to return "Anonymous" if no username is found.
        return usernames.stream()
                        .findFirst()
                        .orElse("Anonymous");
    }
}
