package streams; // Specify the package to ensure proper structure

import java.util.List;          // Import for List handling
import java.util.Optional;      // Import for handling optional results

/**
 * 📚 NumberProcessor.java
 * 
 * This class processes a list of integers and calculates the product of numbers that are greater than or equal to 10.
 * The result is returned as an Optional to safely handle cases where no numbers meet the criteria.
 * 
 * 💡 Key Concepts:
 * - Stream API: Efficient processing of lists.
 * - Filtering: Keeping numbers greater than or equal to 10.
 * - Reduction: Multiplying the filtered numbers.
 * - Optional: Handling cases where the result may be empty.
 */

public class NumberProcessor {

    /**
     * Processes the given list of numbers to find the product of numbers greater than or equal to 10.
     * 
     * @param numbers - A list of integers.
     * @return - An Optional containing the product of numbers >= 10, or an empty Optional if no such numbers exist.
     */
    public Optional<Integer> processNumbers(List<Integer> numbers) {
        return numbers.stream()            // Convert the list to a stream for processing
                .filter(n -> n >= 10)       // Step 1: Filter numbers greater than or equal to 10
                .reduce((a, b) -> a * b);   // Step 2: Multiply the remaining numbers
    }
}
