package streams; // Specify the package name

import java.util.List;                     // Import List for handling collections
import java.util.stream.Collectors;         // Import Collectors for stream processing

/**
 * 📚 EmailDomainExtractor.java
 * 
 * This class provides a method to extract unique email domains from a given list of email addresses.
 * 
 * 💡 Key Concepts:
 * - Stream API: Efficient processing of lists with filtering and mapping.
 * - Email Validation: Ensuring valid email format.
 * - Distinct Elements: Removing duplicate domains from the result.
 */

public class EmailDomainExtractor {

    /**
     * Extracts unique domains from a list of email addresses.
     * 
     * @param emails - A list of email addresses.
     * @return - A list of unique email domains in lowercase.
     */
    public List<String> extractDomains(List<String> emails) {
        return emails.stream() // Convert the list to a stream for processing
                // Step 1: Filter valid email addresses
                .filter(email -> email.contains("@")                                 // Must contain '@'
                        && email.indexOf('@') == email.lastIndexOf('@')               // Only one '@' allowed
                        && email.indexOf('@') > 0                                     // Must have something before '@'
                        && email.indexOf('@') < email.length() - 1)                   // Must have something after '@'
                // Step 2: Map each valid email to its domain part and convert to lowercase
                .map(email -> email.substring(email.indexOf('@') + 1).toLowerCase())
                // Step 3: Remove duplicates using distinct()
                .distinct()
                // Step 4: Collect the result into a list
                .collect(Collectors.toList());
    }
}
