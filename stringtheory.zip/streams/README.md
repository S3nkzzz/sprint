# 📚 Streams

## 📝 Description:

This folder contains Java programs that utilize the Stream API for efficient data processing and functional programming. These tasks are focused on working with collections and streams to perform data filtering, mapping, and aggregation. 🚀

---

## 💡 Skills Acquired:

* Using Java Streams for data processing.
* Applying stream operations such as `map`, `filter`, `reduce`, and `collect`.
* Implementing custom stream functions for specific tasks.
* Extracting and processing information from structured data.
* Performing efficient data transformation and aggregation.

---

## 📂 Program List and Features:

1. **NumberFilter:**

   * Filters even and odd numbers from a list.
   * Demonstrates usage of `filter()` and `collect()`.

2. **NumberProcessor:**

   * Processes a list of integers and applies transformations.
   * Uses `map()` and `reduce()` for calculation.

3. **StreamPolice:**

   * Monitors data flow and performs validation checks.
   * Demonstrates complex stream chaining.

4. **StringToIntConverter:**

   * Converts strings to integers, removing non-numeric characters.
   * Uses `map()` and exception handling for robustness.

5. **WordLengthAnalyzer:**

   * Analyzes the length of words in a sentence.
   * Uses `mapToInt()` to extract lengths.

---

## 🚀 How to Run:

1. Open a terminal in the Streams directory.
2. Compile the desired Java file:

   ```bash
   javac FileName.java
   ```
3. Run the compiled file:

   ```bash
   java FileName
   ```

### Usage Example:

```bash
javac NumberFilter.java
java NumberFilter
```

---

## 🗝️ Key Concepts Covered:

* Stream API: Functional programming with streams
* Data Transformation: Mapping, filtering, and reducing
* Aggregation: Summing and collecting results
* Error Handling: Robust stream operations

Happy Coding! 😊🚀
