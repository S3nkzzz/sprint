package streams;

import java.util.List;                 // Import List for handling collections
import java.util.stream.Collectors;    // Import Collectors for collecting stream results

/**
 * 📚 StringToIntConverter.java
 * 
 * This class provides a method to convert a list of strings into a list of integers.
 * 
 * 💡 Key Concepts:
 * - Stream API: Efficient processing of lists.
 * - Mapping: Transforming strings to integers.
 * - Exception Handling: Assumes valid integer strings are provided.
 */

public class StringToIntConverter {

    /**
     * Converts a list of strings to a list of integers.
     * 
     * @param strings - A list of strings containing numeric values.
     * @return - A list of integers after conversion.
     * @throws NumberFormatException - If any string cannot be converted to an integer.
     */
    public List<Integer> convertStringListToIntList(List<String> strings) {
        // Use Stream API to convert strings to integers
        return strings.stream()
            .map(Integer::parseInt) // Step 1: Convert each string to an integer
            .collect(Collectors.toList()); // Step 2: Collect the results into a list
    }
}
