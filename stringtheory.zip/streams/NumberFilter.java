package streams;

import java.util.ArrayList;    // Import for ArrayList
import java.util.List;         // Import for List
import java.util.Random;       // Import for generating random numbers

/**
 * 📚 NumberFilter.java
 * 
 * This class generates a list of random integers and provides methods to:
 * - Filter prime numbers.
 * - Filter numbers divisible by 3 but not by 5.
 * - Sort numbers not divisible by 3 or 5 in descending order.
 * - Calculate the average of the sorted remaining numbers.
 * 
 * 💡 Key Concepts:
 * - Random Number Generation: Using seeds for reproducibility.
 * - Prime Number Check: Efficiently identifying prime numbers.
 * - Stream API and Filtering: Applying conditions to lists.
 * - Sorting and Average Calculation: Managing numerical data efficiently.
 */

public class NumberFilter {

    private List<Integer> numbers; // List of random integers

    /**
     * Constructor: Generates a list of random integers.
     * 
     * @param count - The number of random integers to generate.
     * @param seed  - The seed for random number generation.
     */
    public NumberFilter(int count, long seed) {
        this.numbers = generateRandomNumbers(count, seed);
    }

    /**
     * Generates a list of random integers between -1000 and 1000.
     * 
     * @param count - Number of integers to generate.
     * @param seed  - Seed for random number generator.
     * @return - List of random integers.
     */
    private List<Integer> generateRandomNumbers(int count, long seed) {
        List<Integer> result = new ArrayList<>();
        Random rand = new Random(seed); // Initialize with seed for consistency

        // Generate random integers in the range -1000 to 1000
        for (int i = 0; i < count; i++) {
            int num = rand.nextInt(2001) - 1000;
            result.add(num);
        }

        return result;
    }

    /**
     * Retrieves all prime numbers from the generated list.
     * 
     * @return - A list of prime numbers.
     */
    public List<Integer> getAllPrimeNumbers() {
        List<Integer> primes = new ArrayList<>();

        for (int num : numbers) {
            if (isPrime(num)) {
                primes.add(num);
            }
        }

        return primes;
    }

    /**
     * Checks if a number is prime.
     * 
     * @param n - The number to check.
     * @return - True if prime, false otherwise.
     */
    private boolean isPrime(int n) {
        if (n <= 1) return false;
        if (n == 2) return true;

        // Check divisibility up to the square root of the number
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) return false;
        }

        return true;
    }

    /**
     * Filters numbers that are divisible by 3 but not by 5.
     * 
     * @return - A list of integers meeting the condition.
     */
    public List<Integer> getDivisibleBy3ButNot5() {
        List<Integer> filtered = new ArrayList<>();

        for (int num : numbers) {
            if (num % 3 == 0 && num % 5 != 0) {
                filtered.add(num);
            }
        }

        return filtered;
    }

    /**
     * Retrieves numbers that are not divisible by 3 or 5 and sorts them in descending order.
     * 
     * @return - A sorted list of remaining numbers.
     */
    public List<Integer> getSortedRemainingNumbers() {
        List<Integer> remaining = new ArrayList<>();

        for (int num : numbers) {
            if (num % 3 != 0 && num % 5 != 0) {
                remaining.add(num);
            }
        }

        // Sort in descending order
        remaining.sort((a, b) -> b - a);
        return remaining;
    }

    /**
     * Computes the average of numbers from getSortedRemainingNumbers.
     * 
     * @return - The average value of the filtered numbers.
     */
    public double computeAverageOfRemainingNumbers() {
        List<Integer> remaining = getSortedRemainingNumbers();

        if (remaining.isEmpty()) return 0.0;

        double sum = 0.0;
        for (int num : remaining) {
            sum += num;
        }

        return sum / remaining.size();
    }
}
