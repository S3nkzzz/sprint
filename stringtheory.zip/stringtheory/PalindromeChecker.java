package stringtheory;

/**
 * 📚 PalindromeChecker.java
 * 
 * This class provides a method to check whether a given string is a palindrome.
 * A palindrome is a word, phrase, number, or other sequence of characters 
 * that reads the same forward and backward, ignoring spaces, punctuation, and capitalization.
 * 
 * 💡 Key Concepts:
 * - String Cleaning: Removing non-alphanumeric characters.
 * - Case Insensitivity: Converting strings to lowercase for uniform comparison.
 * - Reversing Strings: Using StringBuilder to reverse efficiently.
 */

public class PalindromeChecker {

    /**
     * Checks whether the given string is a palindrome.
     * 
     * @param input - The string to be checked.
     * @return - True if the input is a palindrome, false otherwise.
     */
    public static boolean isPalindrome(String input) {
        // Step 1: Clean the input by removing non-alphanumeric characters and converting to lowercase
        String cleaned = input.replaceAll("[^A-Za-z0-9]", "").toLowerCase();

        // Step 2: Reverse the cleaned string
        String reversed = new StringBuilder(cleaned).reverse().toString();

        // Step 3: Compare the cleaned and reversed strings for equality
        return cleaned.equals(reversed);
    }
}
