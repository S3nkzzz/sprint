package stringtheory;

import java.time.DayOfWeek;   // Import for handling days of the week
import java.time.LocalDate;   // Import for handling date operations

/**
 * 📚 WeekendCalculator.java
 * 
 * This class calculates the number of weekend days (Saturday and Sunday) between two given dates.
 * It iterates through each day from the start date to the end date and counts the weekends.
 * 
 * 💡 Key Concepts:
 * - Date Iteration: Using LocalDate to iterate day by day.
 * - Weekend Identification: Using DayOfWeek enum to detect Saturdays and Sundays.
 * - Efficiency: Uses a loop to traverse the date range.
 */

public class WeekendCalculator {

    /**
     * Counts the number of weekend days between two given dates.
     * 
     * @param start - The start date (inclusive).
     * @param end - The end date (inclusive).
     * @return - The number of weekend days (Saturday and Sunday) within the given range.
     */
    public long countWeekendDays(LocalDate start, LocalDate end) {
        long count = 0; // Counter for weekend days

        // Iterate from the start date to the end date
        for (LocalDate date = start; !date.isAfter(end); date = date.plusDays(1)) {
            // Get the day of the week for the current date
            DayOfWeek day = date.getDayOfWeek();
            
            // Check if the current day is Saturday or Sunday
            if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
                count++;  // Increment the weekend counter
            }
        }

        return count; // Return the total number of weekend days
    }
}
