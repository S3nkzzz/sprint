# 📚 String Theory

## 📝 Description:

This folder contains Java programs that focus on string manipulation, text processing, and analysis. These tasks are aimed at mastering methods for handling strings and implementing algorithms related to textual data. 🚀

---

## 💡 Skills Acquired:

* Working with strings and characters in Java.
* Applying text processing techniques.
* Implementing algorithms for string analysis.
* Using regular expressions for pattern matching.
* Checking for palindromes, anagrams, and formatting strings.

---

## 📂 Program List and Features:

1. **AnagramChecker:**

   * Determines whether two strings are anagrams.
   * Uses sorting and comparison for validation.

2. **PalindromeChecker:**

   * Checks whether a given word is a palindrome.
   * Uses `StringBuilder` for reversing strings.

3. **AreaCalculator:**

   * Calculates the area of geometric shapes based on string input.
   * Demonstrates parsing and string manipulation.

4. **CalendarBuilder:**

   * Generates a simple calendar layout.
   * Uses date formatting and string concatenation.

5. **DayChecker:**

   * Determines the day of the week for a given date.
   * Uses date parsing and formatting methods.

---

## 🚀 How to Run:

1. Open a terminal in the String Theory directory.
2. Compile the desired Java file:

   ```bash
   javac FileName.java
   ```
3. Run the compiled file:

   ```bash
   java FileName
   ```

### Usage Example:

```bash
javac AnagramChecker.java
java AnagramChecker
```

---

## 🗝️ Key Concepts Covered:

* String Manipulation: Reversing, formatting, and comparing strings
* Algorithmic Thinking: Anagram and palindrome validation
* Date Handling: Formatting and parsing dates
* Regex Usage: Pattern matching and validation

Happy Coding! 😊🚀
