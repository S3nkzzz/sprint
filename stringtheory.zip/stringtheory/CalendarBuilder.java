package stringtheory;

import java.time.LocalDate;   // Import for working with dates
import java.time.Month;      // Import for month representation

/**
 * 📚 CalendarBuilder.java
 * 
 * This class provides a method to generate a formatted calendar for a given month and year.
 * The calendar starts on Monday and displays days in a grid format.
 * 
 * 💡 Key Concepts:
 * - Date Handling: Uses LocalDate and Month from the java.time package.
 * - String Formatting: Uses StringBuilder for efficient string concatenation.
 * - Day Alignment: Ensures that the calendar aligns correctly based on the starting day of the week.
 */

public class CalendarBuilder {

    /**
     * Builds a formatted calendar for the specified month and year.
     * 
     * @param monthName - The name of the month (e.g., "January").
     * @param year - The year for which the calendar should be built.
     * @return - A formatted calendar as a string.
     */
    public static String buildCalendar(String monthName, int year) {

        // Step 1: Convert month name to uppercase and find the corresponding Month enum
        Month month = Month.valueOf(monthName.toUpperCase());

        // Step 2: Get the first day of the month and calculate the number of days
        LocalDate firstDay = LocalDate.of(year, month, 1);
        int daysInMonth = month.length(firstDay.isLeapYear());

        // Step 3: Prepare the calendar header
        StringBuilder calendar = new StringBuilder();
        calendar.append(monthName.toUpperCase()).append(" ").append(year).append("\n");
        calendar.append("Mon Tue Wed Thu Fri Sat Sun\n");

        // Step 4: Determine the starting day of the week (1=Monday, 7=Sunday)
        int startDay = firstDay.getDayOfWeek().getValue();

        // Step 5: Current day counter
        int currentDay = 1;

        // Step 6: Add leading spaces for the first week
        for (int i = 1; i < startDay; i++) {
            calendar.append("    "); // Four spaces for alignment
        }

        // Step 7: Generate the calendar day by day
        while (currentDay <= daysInMonth) {
            for (int i = startDay; i <= 7 && currentDay <= daysInMonth; i++) {
                // Align single-digit numbers with two spaces
                if (currentDay < 10) {
                    calendar.append("  ").append(currentDay); // Two leading spaces for single-digit numbers
                } else {
                    calendar.append(" ").append(currentDay); // One leading space for double-digit numbers
                }

                // Add space between days, except for the last day of the week or month
                if (i < 7 && currentDay != daysInMonth) {
                    calendar.append(" ");
                }

                // Move to the next day
                currentDay++;
            }

            // Start a new line for the next week, if not the last day of the month
            if (currentDay <= daysInMonth) {
                calendar.append("\n");
            }

            // Reset start day to 1 (Monday) for subsequent weeks
            startDay = 1;
        }

        // Return the formatted calendar, removing any trailing whitespace
        return calendar.toString().stripTrailing();
    }
}
