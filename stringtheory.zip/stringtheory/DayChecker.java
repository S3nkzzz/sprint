package stringtheory;

import java.time.DayOfWeek;  // Import to work with days of the week
import java.time.LocalDate;  // Import to handle date representation

/**
 * 📚 DayChecker.java
 * 
 * This class provides a method to check the type of a given day.
 * It categorizes the day as:
 * - "Weekend" for Saturday and Sunday.
 * - "Hump Day!" for Wednesday.
 * - "Weekday" for any other day.
 * 
 * 💡 Key Concepts:
 * - Enum Usage: Uses DayOfWeek for easy comparison.
 * - Switch Expressions: Modern syntax for better readability.
 * - LocalDate: Efficient handling of date objects.
 */

public class DayChecker {

    /**
     * Checks the type of a given date (weekend, weekday, hump day).
     * 
     * @param date - A LocalDate object representing the date to check.
     * @return - A string indicating whether the date is a weekend, a weekday, or "Hump Day!".
     */
    public static String checkDayType(LocalDate date) {
        // Step 1: Get the day of the week from the date
        DayOfWeek day = date.getDayOfWeek();

        // Step 2: Use a switch expression to determine the type of day
        return switch (day) {
            case SATURDAY, SUNDAY -> "Weekend";    // Saturday and Sunday are weekends
            case WEDNESDAY -> "Hump Day!";          // Wednesday is specifically marked as "Hump Day!"
            default -> "Weekday";                  // All other days are considered weekdays
        };
    }
}
