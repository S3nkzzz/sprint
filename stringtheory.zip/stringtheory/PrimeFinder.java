package stringtheory;

import java.util.ArrayList;  // Import for using ArrayList
import java.util.List;       // Import for using List interface

/**
 * 📚 PrimeFinder.java
 * 
 * This class provides methods to find prime numbers up to a specified limit.
 * A prime number is a natural number greater than 1 that has no positive divisors other than 1 and itself.
 * 
 * 💡 Key Concepts:
 * - Prime Number Calculation: Efficiently checking whether a number is prime.
 * - Iteration and Conditional Logic: Using loops to find primes.
 * - List Handling: Storing primes in an ArrayList.
 */

public class PrimeFinder {

    /**
     * Finds all prime numbers up to a given limit.
     * 
     * @param limit - The upper limit up to which prime numbers are found.
     * @return - A list of integers containing all primes up to the limit.
     */
    public static List<Integer> findPrimesUpTo(int limit) {
        List<Integer> primes = new ArrayList<>();  // Initialize list to store prime numbers

        // Loop through numbers from 2 to the specified limit
        for (int number = 2; number <= limit; number++) {
            // Check if the current number is prime
            if (isPrime(number)) {
                primes.add(number);  // Add prime number to the list
            }
        }

        return primes;  // Return the list of prime numbers
    }

    /**
     * Checks whether a given number is prime.
     * 
     * @param n - The number to check for primality.
     * @return - True if the number is prime, false otherwise.
     */
    private static boolean isPrime(int n) {
        // Step 1: Quick elimination for numbers less than 2
        if (n < 2) return false;

        // Step 2: Check divisibility from 2 up to the square root of n
        for (int i = 2; i * i <= n; i++) {
            // If n is divisible by any number in this range, it is not prime
            if (n % i == 0) return false;
        }

        // Step 3: If no divisors were found, the number is prime
        return true;
    }
}
