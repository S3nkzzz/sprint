package stringtheory;

/**
 * 📚 AreaCalculator.java
 * 
 * This class provides methods to calculate the area of different geometric shapes:
 * - Square: Calculated from the side length.
 * - Rectangle: Calculated from width and height.
 * - Circle: Calculated from the radius.
 * 
 * 💡 Key Concepts:
 * - Method Overloading: Multiple methods with the same name but different parameters.
 * - Precision Handling: Rounding results to two decimal places.
 * - Conditional Calculation: Handling cases where the area is not calculated.
 */

public class AreaCalculator {

    /**
     * Calculates the area of a square.
     * 
     * @param side - The length of one side of the square.
     * @return - The area of the square, rounded to two decimal places.
     */
    public static double calculateArea(double side) {
        // Step 1: Calculate the area (side * side)
        // Step 2: Round the result to two decimal places
        return Math.round(side * side * 100.0) / 100.0;
    }

    /**
     * Calculates the area of a rectangle.
     * 
     * @param width  - The width of the rectangle.
     * @param height - The height of the rectangle.
     * @return - The area of the rectangle, rounded to two decimal places.
     */
    public static double calculateArea(double width, double height) {
        // Step 1: Calculate the area (width * height)
        // Step 2: Round the result to two decimal places
        return Math.round(width * height * 100.0) / 100.0;
    }

    /**
     * Calculates the area of a circle if the flag is true.
     * 
     * @param radius     - The radius of the circle.
     * @param calculate  - A flag indicating whether to calculate the area.
     * @return - The area of the circle if calculated, or NaN if not.
     */
    public static double calculateArea(double radius, boolean calculate) {
        // Check if calculation is required
        if (calculate) {
            // Step 1: Calculate the area (π * r^2)
            double area = Math.PI * radius * radius;
            // Step 2: Round the result to two decimal places
            return Math.round(area * 100.0) / 100.0;
        } else {
            // Return NaN if calculation is not requested
            return Double.NaN;
        }
    }
}
