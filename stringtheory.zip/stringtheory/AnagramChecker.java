package stringtheory;

import java.util.Arrays;  // Importing Arrays for sorting and comparison

/**
 * 📚 AnagramChecker.java
 * 
 * This class provides a method to check whether two given strings are anagrams.
 * Anagrams are words or phrases formed by rearranging the letters of another, using all the original letters exactly once.
 * 
 * 💡 Key Concepts:
 * - Character Sorting: Sorting both strings and comparing for equality.
 * - Case Insensitivity: Converting strings to lowercase for uniform comparison.
 * - Array Comparison: Using Arrays.equals() to check if sorted arrays are identical.
 */

public class AnagramChecker {

    /**
     * Checks whether two given strings are anagrams.
     * 
     * @param str1 - The first string to compare.
     * @param str2 - The second string to compare.
     * @return - True if the strings are anagrams, false otherwise.
     */
    public static boolean areAnagrams(String str1, String str2) {
        // Step 1: Convert both strings to lowercase to ignore case differences
        str1 = str1.toLowerCase();
        str2 = str2.toLowerCase();

        // Step 2: Check if the lengths are different; if yes, they cannot be anagrams
        if (str1.length() != str2.length()) {
            return false;
        }

        // Step 3: Convert both strings to character arrays
        char[] arr1 = str1.toCharArray();
        char[] arr2 = str2.toCharArray();

        // Step 4: Sort both character arrays
        Arrays.sort(arr1);
        Arrays.sort(arr2);

        // Step 5: Compare sorted arrays for equality
        return Arrays.equals(arr1, arr2);
    }
}
