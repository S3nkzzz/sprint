### 📝 **README.md — kood/Jõhvi Sprint Portfolio**

---

## 🌟 **Welcome to My kood/Jõhvi Sprint Journey!**

👋 Hi there! I'm **Jevgeni Tšernokozov**, a passionate learner from the **16th Sprint at kood/Jõhvi**.
Over the past three weeks, I've been diving deep into **Java programming**, mastering essential concepts, and building projects that challenged and sharpened my skills.

---

### 🏫 **What We Learned:**

During the sprint, we covered a wide range of topics, including:

* ✅ **Basic Syntax and Data Types:** *Variables, primitive types, and control structures.*
* ✅ **Object-Oriented Programming (OOP):** *Classes, inheritance, polymorphism, and encapsulation.*
* ✅ **Data Structures:** *Arrays, lists, sets, and maps.*
* ✅ **Streams and Functional Programming:** *Processing collections and data with Java Streams.*
* ✅ **File I/O:** *Reading and writing files, handling CSV.*
* ✅ **Error Handling:** *Using try-catch blocks and custom exceptions.*
* ✅ **Version Control with Git:** *Managing code and collaborating via Gitea.*
* ✅ **Teamwork and Collaboration:** *Group projects with structured code sharing.*

---

## 📂 **Repository Structure:**

```
📁 My Sprint Projects
├── 📁 First Grade Java     # Basic syntax and logic tasks
├── 📁 Second Grade         # Advanced functions and problem-solving
├── 📁 Streams              # Working with data processing in Java
├── 📁 String Theory        # String manipulations and text processing
├── 📁 List of Things       # Collections and data structure tasks
├── 📁 Micro Problems       # Small coding challenges
├── 📁 Introduction to Shell # Bash and shell scripting basics
├── 📁 Group Tasks          # Collaborative projects
├── 📁 My Projects          # Personal applications and custom solutions
```

---

## 🚀 **Project Highlights:**

#### 🎮 **Wordle Game (Group Project)**

* A **Java-based CLI game** that mimics the popular *Wordle*.
* **Features:**

  * *Random word selection from a dictionary.*
  * *Color-coded feedback for guesses.*
  * *Statistics tracking across sessions.*
* **Collaborators:** *Aleksandra Poljakova, Jevgeni Tšernokozov*

#### 💰 **Green Day Bank (Personal Project)**

* A **simple command-line banking application.**
* **Features:**

  * *User login system.*
  * *Savings and investment account management.*
  * *Money transfer and investment in low, medium, and high-risk funds.*

---

## 💻 **How to Use:**

1. **Clone the repository:**

   ```bash
   git clone https://gitea.kood.tech/jevgenitsernokozov/sprint-portfolio.git
   ```
2. **Navigate to a project folder:**

   ```bash
   cd "My Sprint Projects/WordleGame"
   ```
3. **Compile the Java files:**

   ```bash
   javac -d build $(find . -name "*.java")
   ```
4. **Run the project:**

   ```bash
   java -cp build WordleGame
   ```

---

## 🛠️ **Commands to Get Started:**

* **Git Basics:**

  ```bash
  git init                 # Initialize a new repo
  git add .                # Add all changes
  git commit -m "Message"  # Commit changes
  git push origin main     # Push to remote repo
  ```
* **Creating Your First Java Program:**

  ```java
  public class HelloWorld {
      public static void main(String[] args) {
          System.out.println("Hello, kood/Jõhvi!");
      }
  }
  ```

  ```bash
  javac HelloWorld.java
  java HelloWorld
  ```

---

## 🎯 **Key Takeaways:**

* **Problem Solving:** *Learned to break down complex problems into manageable parts.*
* **Collaboration:** *Worked in teams to build full-fledged applications.*
* **Version Control:** *Mastered Git for efficient code management.*
* **Code Quality:** *Emphasized clean, readable, and well-documented code.*

---

## 📸 **Screenshots:**

| Description                  | Screenshot |
| ---------------------------- | ---------- |
| *Wordle Game in action*      |            |
| *Green Day Bank transaction* |            |
| *Project Structure Overview* |            |

---

## 🌍 **Connect with Me:**

* **GitHub:** [Jevgeni Tšernokozov](https://gitea.kood.tech/jevgenitsernokozov)
* **LinkedIn:** [Your LinkedIn Profile](https://linkedin.com/in/yourprofile)

---

Thank you for visiting my sprint portfolio! 💪🚀
