#!/bin/bash

# 📚 Script: File Count Multiplier
# 
# This script calculates the total number of files and directories
# in the current directory (and all its subdirectories) and then
# multiplies this count by 5.
# 
# 💡 Key Concepts:
# - File Counting: Using 'find' to list all files and directories.
# - Arithmetic Operations: Multiplication using $((...)).
# - Formatted Output: Using printf to display the result.

# Step 1: Use 'find' to list all files and directories recursively from the current location.
# - The 'find .' command lists all files and directories starting from the current folder.
# - 'wc -l' counts the number of lines, which corresponds to the number of items found.
count=$(find . | wc -l)

# Step 2: Multiply the count by 5.
# - Uses the arithmetic expansion syntax $((...)) for multiplication.
result=$((count * 5))

# Step 3: Print the formatted result.
# - Uses printf for a formatted and visually appealing output.
# - '\t' adds a horizontal tab, '\v' adds a vertical tab.
printf "\t\vTotal files * 5: %d\v\n" "$result"
