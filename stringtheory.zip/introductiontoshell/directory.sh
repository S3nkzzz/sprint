#!/bin/bash

# 📚 Script: Navigate and Display README
# 
# This script navigates to a specific subdirectory, displays the content 
# of a README file, and prints the current working directory.
# 
# 💡 Key Concepts:
# - Changing Directories: Using 'cd' to navigate to a specific folder.
# - File Display: Using 'cat' to print the content of a file.
# - Current Directory: Using 'pwd' to show the absolute path.

# Step 1: Navigate to the target directory.
# - The 'cd' command changes the current working directory.
# - If the directory path is incorrect, the script will fail.
cd theDirectory/left/down/beginning

# Step 2: Display the content of the README file.
# - The 'cat' command reads and prints the contents of the specified file.
cat README

# Step 3: Print the current working directory.
# - The 'pwd' command shows the full path of the current directory.
pwd
