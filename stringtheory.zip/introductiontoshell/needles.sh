#!/bin/bash

# 📚 Script: Count Lines Containing "not"
# 
# This script searches for lines containing the word "not" in the file "hay.txt"
# and counts how many times the word appears in the file.
# 
# 💡 Key Concepts:
# - Searching Text: Using 'grep' to find lines with a specific word.
# - Counting Lines: Using 'wc -l' to count the number of matching lines.

# Step 1: Use 'grep' to find lines containing the word "not" in the file "hay.txt".
# Step 2: Pipe the result to 'wc -l' to count the number of lines.
grep "not" hay.txt | wc -l
