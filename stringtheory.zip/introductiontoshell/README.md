# 📚 Introduction to Shell

## 📝 Description:

This folder contains shell scripts developed as part of the Selection Sprint at kood/Jõhvi. These scripts are aimed at introducing basic shell programming concepts, including file manipulation, directory traversal, and text processing. 🚀

---

## 💡 Skills Acquired:

* Understanding basic shell scripting syntax.
* Navigating the file system using shell commands.
* Creating simple scripts for file and text manipulation.
* Automating repetitive tasks using loops and conditions.
* Handling input and output through the terminal.

---

## 📂 Script List and Features:

1. **count.sh:**

   * Counts the number of files in a given directory.
   * Demonstrates the use of loops and conditionals.

2. **directory.sh:**

   * Displays the current directory path.
   * Uses the `pwd` command to print the working directory.

3. **files.sh:**

   * Lists all files in the specified directory.
   * Uses the `ls` command with filtering options.

4. **find.sh:**

   * Searches for a file with a given name within a directory.
   * Uses the `find` command with name matching.

5. **loop.sh:**

   * Demonstrates a simple loop structure.
   * Uses a `for` loop to print numbers or strings.

6. **hello.sh:**

   * Prints a welcome message to the terminal.
   * Uses simple `echo` command.

7. **listing.sh:**

   * Lists all files and directories in the current location.
   * Uses the `ls -l` command for detailed output.

8. **needles.sh:**

   * Searches for a keyword within a file.
   * Uses `grep` for efficient text searching.

---

## 🚀 How to Run:

1. Open a terminal in the Introduction to Shell directory.
2. Run the desired shell script:

   ```bash
   bash scriptname.sh
   ```

### Usage Example:

```bash
bash hello.sh
```

---

## 🗝️ Key Concepts Covered:

* Shell Scripting Basics: Commands, loops, conditions
* File System Navigation: Finding and listing files
* Text Processing: Searching and filtering text
* Automating Tasks: Creating reusable scripts

Happy Scripting! 😊🚀
