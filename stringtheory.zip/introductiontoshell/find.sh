#!/bin/bash

# 📚 Script: Find Files Matching Patterns
# 
# This script finds files in the current directory and its subdirectories
# whose names match any of the following patterns:
# - Starts with 'a'
# - Ends with 'z'
# - Starts with 'z' and ends with 'a'
# 
# 💡 Key Concepts:
# - Pattern Matching: Using wildcards with the 'find' command.
# - Grouping Conditions: Using parentheses to group conditions.
# - Logical OR: Using '-o' to combine multiple search criteria.

# Step 1: Find files based on specified patterns.
find . \( -name "a*" -o -name "*z" -o -name "z*a" \)
