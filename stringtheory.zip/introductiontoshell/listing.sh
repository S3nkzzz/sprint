#!/bin/bash
ls -p -u -t -m --ignore=".*"