#!/bin/bash

# 📚 Script: Special Character Handling
# 
# This script demonstrates creating files and directories with special characters,
# copying files to special-named directories, and moving or deleting a file 
# based on an environment variable.
# 
# 💡 Key Concepts:
# - Creating Files with Special Characters: Using touch with escaped characters.
# - Creating Directories: Using mkdir with special characters.
# - Conditional Statements: Using if-elif-else to decide file operations.
# - Environment Variables: Using $MOVE_A to control behavior.

# Step 1: Create files with special characters in their names.
touch a         # Simple file named "a"
touch '!'       # File named "!"
touch '\'       # File named "\"
touch '"'       # File named '"'

# Step 2: Create a directory with a backtick in its name.
mkdir '`'       # Directory named "`"

# Step 3: Copy the file named "!" into the directory named "`".
cp '!' '`'      # Copy the file "!" to the directory "`"

# Step 4: Conditionally move or delete the file "a".
# - The decision is based on the environment variable $MOVE_A.
if [ "$MOVE_A" = "yes" ]; then
    # If MOVE_A is "yes", move file "a" into the directory "`".
    mv a '`'
elif [ "$MOVE_A" = "no" ]; then
    # If MOVE_A is "no", remove the file "a".
    rm a
fi
