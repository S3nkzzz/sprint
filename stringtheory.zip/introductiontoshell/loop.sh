#!/bin/bash

# 📚 Script: Print Name Multiple Times
# 
# This script takes a number as an argument and prints a message that number of times.
# If the given number exceeds 100, it will be limited to 100.
# 
# 💡 Key Concepts:
# - Command-Line Arguments: Taking input from the user.
# - Conditional Logic: Limiting the maximum value.
# - Looping: Using a for loop to print the message multiple times.

# Step 1: Get the count from the first argument passed to the script.
count=$1

# Step 2: Check if the count exceeds the maximum allowed value (100).
if [ "$count" -gt 100 ]; then
  # If count is greater than 100, set it to 100.
  count=100
fi

# Step 3: Print the message the specified number of times.
for ((i = 1; i <= count; i++)); do
  # Print the message with the current iteration number.
  echo "$i times I've printed jevgenitsernokozov"
done
