# 📚 My Projects

## 📝 Description:

This folder contains individual projects developed by Jevgeni Tsernokozov and Aleksandra Poljakova as part of the Selection Sprint at kood/Jõhvi. Each project demonstrates unique problem-solving skills and mastery of Java programming concepts. 🚀

---

## 💡 Skills Acquired:

* Advanced Java programming and algorithm implementation.
* Mastery of data handling, input/output, and file manipulation.
* Developing interactive command-line applications.
* Applying design patterns and object-oriented principles.
* Writing modular and maintainable code.

---

## 📂 Project List and Features:

1. **Wordle Game:**

   * Command-line game that mimics the popular Wordle.
   * The player guesses a 5-letter word with feedback on accuracy:

     * Green: Correct letter and position.
     * Yellow: Correct letter, wrong position.
     * White: Incorrect letter.
   * Tracks statistics and saves results to a CSV file.
   * Features random word selection and replay option.

2. **Green Day Bank:**

   * Command-line banking application for managing user accounts.
   * Supports login, balance check, deposits, withdrawals, and transfers.
   * User-friendly menu and secure input handling.
   * Tracks transactions and user balances.

---

## 🚀 How to Run:

1. Open a terminal in the My Projects directory.
2. Compile the desired Java file:

   ```bash
   javac FileName.java
   ```
3. Run the compiled file:

   ```bash
   java FileName
   ```

### Usage Example:

```bash
javac WordleGame.java
java WordleGame
```

---

## 🗝️ Key Concepts Covered:

* Command-Line Interface (CLI) Design
* Data Persistence: CSV and file handling
* Game Logic: Feedback and scoring
* User Authentication: Login and secure operations

Happy Coding! 😊🚀
