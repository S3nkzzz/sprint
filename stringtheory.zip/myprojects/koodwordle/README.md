```
╔════════════════════════════════════════╗
║     🎮 WORDLE GAME - Terminal Edition ║
╚════════════════════════════════════════╝
```

> A stylish, interactive Wordle game for the command line with colorful feedback and persistent game statistics.

---

## 🌟 Features

- 🎯 Guess a 5-letter word in 6 tries.
- 🟩 Green = Correct letter & position  
- 🟨 Yellow = Correct letter, wrong position  
- ⬜ White = Incorrect letter
- 🗂 Tracks and stores stats (CSV format)
- 🎨 Beautiful color-coded CLI (ANSI escape codes)
- 🔁 Stats persist between games
- 📑 Graceful error handling (missing file, bad index)

---

## ✔️ Requirements

- Java 21+
- Git
- Terminal supporting ANSI colors
- `wordle-words.txt` (ignored by Git)

---

## 🛠️ Run Instructions

```bash
javac -d build WordleGame.java
java -cp build WordleGame [INDEX]
```

📌 Replace `[INDEX]` with the index of the word from `wordle-words.txt`.

---

## 📁 Project Structure

| File | Description |
|------|-------------|
| `WordleGame.java` | Main entry point, launches the game |
| `game/WordleEngine.java` | Game logic and input validation |
| `game/Feedback.java` | Colored feedback printer |
| `io/WordLoader.java` | Loads words from file |
| `io/StatsManager.java` | Saves and displays game stats |
| `model/GameResult.java` | Represents game stats for CSV |

---

## 🎨 ANSI Color Codes

| Color | Description |
|-------|-------------|
| 🟩 `[32m` | Correct letter and position |
| 🟨 `[33m` | Correct letter, wrong position |
| ⬜ Default | Incorrect letter |

---

## 🧪 Example Gameplay

```bash
Remaining letters: A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
Attempt 1/6. Enter your guess:
> CRANE

🟩 C ⬜ R 🟨 A ⬜ N

Remaining letters...
```

---

## 📊 Stats Output (CSV)

```
username,secretWord,attempts,win/loss
Player,CRANE,3,win
Player,TOAST,6,loss
```

---

## 📬 Authors

- 🧠 Jevgeni Tšernokozov (S3nkzzz)
- 🧩 Aleksandra Poljakova

---

## 🧠 Tips

> 💡 Use the correct word index or handle errors gracefully.  
> 💾 Don’t forget: `wordle-words.txt` is local and must be present!

---