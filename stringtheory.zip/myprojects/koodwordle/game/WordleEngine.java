/***********************************************************
 * WordleEngine.java
 * 
 * Core logic for the Wordle command-line game.
 * Handles gameplay loop, input validation, letter feedback,
 * and tracking of attempts.
 *
 * Written by: Aleksandra Poljakova & Jevgeni Tšernokozov
 ***********************************************************/

 package game;

 import java.util.*;
 import model.GameResult;
 
 public class WordleEngine {
     private final String secretWord;
     private final List<String> wordList;
     private final Scanner scanner;
     private Set<Character> remainingLetters;
 
     public WordleEngine(String secretWord, List<String> wordList, Scanner scanner) {
         this.secretWord = secretWord.toLowerCase();
         this.wordList = wordList;
         this.scanner = scanner;
         this.remainingLetters = createAlphabetSet();
     }
 
     public GameResult play() {
        int attempts = 0;
        while (attempts < 6) {
            System.out.println("Remaining letters: " + formatRemainingLetters(remainingLetters));
            System.out.print("Enter your guess: ");
            String guess = scanner.nextLine().trim().toLowerCase();

             if (guess.length() != 5) {
                 System.out.println("Your guess must be exactly 5 letters long");
                 continue;
             }
 
             if (!guess.matches("[a-z]+")) {
                 System.out.println("Your guess must only contain lowercase letters");
                 continue;
             }
 
             if (!wordList.contains(guess)) {
                 System.out.println("Word not in list. Please enter a valid word.");
                 continue;
             }
 
             Feedback.printColoredFeedback(guess, secretWord);

             for (int i = 0; i < 5; i++) { // для буквы i в попыточном слове
                boolean remove = true;
                for (int j = 0; j < 5; j++) {   // для буквы j в секретном слове
                    if (guess.charAt(i) == secretWord.charAt(j)) {  // если буква i в попыточном слове равна букве j в секретном слове
                        remove = false; // не удалять её
                    }
                }
                if (remove == true) { // а иначе удалять
                    remainingLetters.remove(Character.toUpperCase(guess.charAt(i)));
                }
            }
 
             attempts++;
 
             if (guess.equals(secretWord)) {
                System.out.println("Congratulations! You've guessed the word correctly.");
                return new GameResult(secretWord, attempts, "win");
            }
        }

        System.out.println("Game over. The correct word was: " + secretWord);
        return new GameResult(secretWord, attempts, "loss");
        }

        private Set<Character> createAlphabetSet() {
            Set<Character> set = new TreeSet<>();
            for (char c = 'A'; c <= 'Z'; c++) {
                set.add(c);
            }
            return set;
        }
    
        private String formatRemainingLetters(Set<Character> letters) {
            StringBuilder sb = new StringBuilder();
            for (char c : letters) {
                sb.append(c).append(" ");
            }
            return sb.toString().trim();
        }
    }