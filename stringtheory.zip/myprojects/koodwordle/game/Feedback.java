/***********************************************************
 * Feedback.java
 *
 * This class is responsible for comparing the player's guess
 * with the secret word and printing a color-coded result.
 *
 * - Green (G): correct letter in the correct position
 * - Yellow (Y): correct letter in the wrong position
 * - Default (white): incorrect letter
 *
 * Uses ANSI escape codes for coloring in the terminal:
 * - Green: \u001B[32m
 * - Yellow: \u001B[33m
 * - Reset:  \u001B[0m
 *
 * Written by: Aleksandra Poljakova & Jevgeni Tšernokozov
 ***********************************************************/

 package game;

 public class Feedback {
     public static void printColoredFeedback(String guess, String secretWord) {
         char[] feedback = new char[5];
         boolean[] secretUsed = new boolean[5];
 
         // Green
         for (int i = 0; i < 5; i++) {
             if (guess.charAt(i) == secretWord.charAt(i)) {
                 feedback[i] = 'G';
                 secretUsed[i] = true;
             }
         }
 
         // Yellow
         for (int i = 0; i < 5; i++) {
            if (feedback[i] == 'G') continue;

            for (int j = 0; j < 5; j++) {
                if (!secretUsed[j] && guess.charAt(i) == secretWord.charAt(j)) {
                    feedback[i] = 'Y';
                    secretUsed[j] = true;
                    break;
                }
             }
         }
 
         // White
         for (int i = 0; i < 5; i++) {
             if (feedback[i] != 'G' && feedback[i] != 'Y') {
                 feedback[i] = 'W';
             }
         }
 
         StringBuilder sb = new StringBuilder();
         for (int i = 0; i < 5; i++) {
             char letter = Character.toUpperCase(guess.charAt(i));
             switch (feedback[i]) {
                 case 'G' -> sb.append("\u001B[32m").append(letter).append("\u001B[0m");
                 case 'Y' -> sb.append("\u001B[33m").append(letter).append("\u001B[0m");
                 default -> sb.append("\u001B[37m").append(letter).append("\u001B[0m");
             }
         }
 
         System.out.println(sb.toString());

     }
 }