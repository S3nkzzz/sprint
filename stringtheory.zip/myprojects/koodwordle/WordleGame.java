// *******************************************************
// * WordleGame.java                                     *
// *                                                     *
// * Entry point for the Wordle command-line game.       *
// * - Accepts word index as a command-line argument     *
// * - Loads word list from "wordle-words.txt"           *
// * - Starts the game loop using WordleEngine           *
// * - Saves and shows game statistics in stats.csv      *
// *                                                     *
// * Written by: Aleksandra Poljakova & Jevgeni Tšernokozov *
// *******************************************************


import java.io.*;
import java.util.*;
import game.WordleEngine;
import io.WordLoader;
import io.StatsManager;
import model.GameResult;

public class WordleGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            if (args.length == 0) {
                System.out.println("Please provide a number as command line argument");
                return;
            }

            int index;
            try {
                index = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.out.println("Invalid command-line argument. Please launch with a valid number");
                return;
            }

            System.out.print("Enter your username: ");
            String username = scanner.nextLine().trim();

            List<String> wordList = WordLoader.loadWords("wordle-words.txt");
            if (index < 0 || index >= wordList.size()) {
                System.out.println("Invalid word index.");
                return;
            }

            String secretWord = wordList.get(index);
            WordleEngine engine = new WordleEngine(secretWord, wordList, scanner);
            GameResult result = engine.play();

            StatsManager.saveResult("stats.csv", username, result);

            System.out.print("Do you want to see your stats? (yes/no): ");
            String answer = scanner.nextLine().trim().toLowerCase();
            if (answer.equals("yes")) {
                StatsManager.displayStats("stats.csv", username);
            }

            System.out.println("Press Enter to exit...");
            scanner.nextLine();

        } catch (IOException e) {
            System.out.println("Word list file not found.");
        } finally {
            scanner.close();
        }
    }
}

