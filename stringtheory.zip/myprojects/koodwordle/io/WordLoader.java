/***********************************************************
 * WordLoader.java
 * 
 * Responsible for loading the list of 5-letter words from
 * a file named wordle-words.txt. Filters out invalid words
 * and returns a list for the game to use.
 *
 * Written by: Aleksandra Poljakova & Jevgeni Tšernokozov
 ***********************************************************/

 package io;

 import java.io.*;
 import java.util.*;
 
 public class WordLoader {
     public static List<String> loadWords(String filename) throws IOException {
         List<String> words = new ArrayList<>();
         try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
             String line;
             while ((line = br.readLine()) != null) {
                 line = line.trim().toLowerCase();
                 if (line.length() == 5 && line.matches("[a-z]+")) {
                     words.add(line);
                 }
             }
         }
         return words;
     }
 }
 