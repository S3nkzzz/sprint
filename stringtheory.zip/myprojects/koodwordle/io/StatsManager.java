/***********************************************************
 * StatsManager.java
 * 
 * This class handles reading from and writing to the stats.csv file.
 * It is responsible for:
 * - Saving the result of each finished game.
 * - Displaying all previous game results upon request.
 * 
 * Written by: Aleksandra Poljakova & Jevgeni Tšernokozov
 ***********************************************************/
package io;

import java.io.*;
import model.GameResult;

public class StatsManager {
    public static void saveResult(String filename, String username, GameResult result) {
        try (FileWriter fw = new FileWriter(filename, true)) {
            fw.write(username + "," + result.secretWord + "," + result.attempts + "," + result.outcome + "\n");
        } catch (IOException e) {
            System.out.println("Error writing to stats file.");
        }
    }

    public static void displayStats(String filename, String username) {
        int gamesPlayed = 0;
        int gamesWon = 0;
        int totalAttempts = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4 && parts[0].equals(username)) {
                    gamesPlayed++;
                    totalAttempts += Integer.parseInt(parts[2]);
                    if (parts[3].equals("win")) {
                        gamesWon++;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading stats file.");
            return;
        }

        if (gamesPlayed == 0) {
            System.out.println("Stats for " + username + ":");
            System.out.println("No games played yet.");
            return;
        }

        double averageAttempts = (double) totalAttempts / gamesPlayed;
        System.out.println("Stats for " + username + ":");
        System.out.println("Games played: " + gamesPlayed);
        System.out.println("Games won: " + gamesWon);
        System.out.printf("Average attempts per game: %.2f%n", averageAttempts);
    }
}
