/***********************************************************
 * GameResult.java
 *
 * This class is a data model representing a single completed
 * Wordle game. It stores:
 *  - Username
 *  - The secret word
 *  - Number of attempts used
 *  - Result: "win" or "loss"
 *
 * This data is later used for saving into a CSV file via StatsManager.
 *
 * Written by: Aleksandra Poljakova & Jevgeni Tšernokozov
 ***********************************************************/


 package model;

 public class GameResult {
     public final String secretWord;
     public final int attempts;
     public final String outcome;
 
     public GameResult(String secretWord, int attempts, String outcome) {
         this.secretWord = secretWord;
         this.attempts = attempts;
         this.outcome = outcome;
     }
 }
 