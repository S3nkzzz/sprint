package listofthings;

import java.util.ArrayList;
import java.util.List;

/**
 * 📚 Combinations.java
 * 
 * This class generates all possible combinations of increasing digits of a specified length.
 * The combinations are formed by digits from 0 to 9 in strictly ascending order.
 * 
 * 💡 Key Concepts:
 * - Recursion: Generating combinations in a depth-first manner.
 * - Backtracking: Building combinations by adding digits incrementally.
 * - Edge Case Handling: Returning an empty list if the length (n) is less than or equal to 0.
 */

public class Combinations {

    /**
     * Generates all possible combinations of increasing digits of length n.
     * 
     * @param n - The desired length of each combination.
     * @return - A list containing all valid combinations as strings.
     */
    public List<String> combN(int n) {
        // Step 1: Create a list to store the generated combinations.
        List<String> result = new ArrayList<>();

        // Step 2: Handle edge case where the required length is 0 or negative.
        if (n <= 0) {
            return result;
        }

        // Step 3: Start the recursive generation of combinations.
        generateCombinations("", -1, n, result); 
        
        // Step 4: Return the list of combinations.
        return result;
    }

    /**
     * Recursive helper method to generate combinations.
     * 
     * @param current - The current combination being built.
     * @param start - The last digit added to the combination.
     * @param n - The target length of the combination.
     * @param result - The list to store valid combinations.
     */
    private void generateCombinations(String current, int start, int n, List<String> result) {
        // Base case: If the current combination length equals n, add it to the result.
        if (current.length() == n) {
            result.add(current); // Add the completed combination to the result list.
            return;
        }

        // Recursive case: Generate the next digits in increasing order.
        for (int i = start + 1; i <= 9; i++) {
            // Recursively build combinations by appending the next digit.
            generateCombinations(current + i, i, n, result);
        }
    }
}
