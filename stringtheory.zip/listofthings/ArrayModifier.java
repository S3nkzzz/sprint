package listofthings;

import java.util.ArrayList;

/**
 * 📚 ArrayModifier.java
 *
 * This class provides a method to remove a range of elements from an ArrayList of Doubles.
 * The method handles boundary conditions and swaps indices if they are given in the wrong order.
 *
 * 💡 Key Concepts:
 * - ArrayList Manipulation: Using subList().clear() to remove a range of elements.
 * - Index Handling: Ensuring the indices are valid and in correct order.
 * - Input Validation: Preventing out-of-bound errors when accessing the list.
 */

public class ArrayModifier {

    /**
     * Removes elements from the given ArrayList between the specified indices.
     *
     * @param list - The ArrayList of Doubles to be modified.
     * @param index1 - The start index of the removal range.
     * @param index2 - The end index (exclusive) of the removal range.
     * @return - The modified ArrayList with the specified range of elements removed.
     */
    public static ArrayList<Double> removeElementsBetween(ArrayList<Double> list, int index1, int index2) {
        
        // Step 1: Swap indices if they are in the wrong order.
        if (index1 > index2) {
            int temp = index1;
            index1 = index2;
            index2 = temp;
        }

        // Step 2: Ensure indices are within valid list boundaries.
        if (index1 < 0) {
            index1 = 0; // Set to the start of the list if index1 is negative.
        }
        if (index2 > list.size()) {
            index2 = list.size(); // Set to the end of the list if index2 exceeds size.
        }

        // Step 3: Remove elements only if the range is valid (index1 < index2).
        if (index1 < index2) {
            // Using subList() to create a view and clearing the specified range.
            list.subList(index1, index2).clear();
        }

        // Step 4: Return the modified list.
        return list;
    }
}
