package listofthings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 📚 Transformer.java
 * 
 * This class provides a method to transform an integer array based on specific rules:
 * 1. Removes duplicates while preserving the original order.
 * 2. Sorts the unique elements in descending order.
 * 3. Replaces every third element with the sum of the two preceding elements.
 * 4. Reverses the entire list before returning the result.
 * 
 * 💡 Key Concepts:
 * - Removing Duplicates: Uses a LinkedHashSet to maintain order.
 * - Sorting: Uses Collections.reverseOrder() for descending sort.
 * - List Manipulation: Efficiently updates every third element.
 * - Array Conversion: Converts between arrays and lists.
 */

public class Transformer {

    /**
     * Transforms the given integer array based on specific rules.
     * 
     * @param arr - The input integer array to be transformed.
     * @return - A transformed array after applying the specified transformations.
     */
    public static int[] transform(int[] arr) {
        // Step 1: Check for empty or null input and return an empty array if true.
        if (arr == null || arr.length == 0) {
            return new int[0];
        }

        // Step 2: Remove duplicates while preserving the order.
        Set<Integer> uniqueSet = new LinkedHashSet<>();
        for (int num : arr) {
            uniqueSet.add(num);
        }

        // Step 3: Convert the set to a list to allow sorting and manipulation.
        List<Integer> list = new ArrayList<>(uniqueSet);

        // Step 4: Sort the list in descending order.
        list.sort(Collections.reverseOrder());

        // Step 5: Modify every third element to be the sum of the two previous elements.
        for (int i = 2; i < list.size(); i += 3) {
            int sum = list.get(i - 1) + list.get(i - 2);
            list.set(i, sum);
        }

        // Step 6: Reverse the entire list.
        Collections.reverse(list);

        // Step 7: Convert the list back to an integer array.
        int[] result = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i);
        }

        // Step 8: Return the transformed array.
        return result;
    }
}
