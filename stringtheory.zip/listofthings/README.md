# 📚 Final Exam Tasks

## 📝 Description:

This folder contains the final exam tasks from the Selection Sprint at kood/Jõhvi. Each task represents a culmination of learned skills, focusing on solving complex problems using Java. 🚀

---

## 💡 Skills Acquired:

* Advanced problem-solving and algorithm design.
* Utilizing data structures effectively.
* Implementing complex logic in a structured manner.
* Testing and debugging final solutions.
* Writing modular and maintainable code.

---

## 📂 Program List and Features:

1. **Palindrome Finder:**

   * Detects palindrome words and phrases.
   * Uses efficient algorithms to handle large strings.

2. **Anagram Solver:**

   * Finds all possible anagrams of a given word.
   * Uses recursion and backtracking.

3. **Prime Number Generator:**

   * Generates prime numbers within a specified range.
   * Uses the Sieve of Eratosthenes for efficiency.

4. **Tree Traversal:**

   * Implements various tree traversal techniques: Pre-order, In-order, Post-order.
   * Demonstrates recursive and iterative approaches.

5. **Number Sorter:**

   * Sorts a list of numbers using quicksort.
   * Demonstrates divide-and-conquer sorting technique.

---

## 🚀 How to Run:

1. Open a terminal in the Final Exam Tasks directory.
2. Compile the desired Java file:

   ```bash
   javac FileName.java
   ```
3. Run the compiled file:

   ```bash
   java FileName
   ```

### Usage Example:

```bash
javac PalindromeFinder.java
java PalindromeFinder
```

---

## 🗝️ Key Concepts Covered:

* Algorithm Efficiency: Choosing optimal approaches for large data
* Recursion and Backtracking: Implementing complex logic
* Data Structures: Trees and lists
* Sorting and Searching: Efficient algorithms

Happy Coding! 😊🚀
