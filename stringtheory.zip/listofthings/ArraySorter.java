package listofthings;

/**
 * 📚 ArraySorter.java
 * 
 * This class provides a method to sort an array of doubles in ascending order.
 * It uses a simple sorting algorithm (Selection Sort) to arrange the numbers from smallest to largest.
 * 
 * 💡 Key Concepts:
 * - Sorting Algorithm: Selection Sort for simplicity.
 * - Array Manipulation: Rearranging elements in ascending order.
 * - Swap Operation: Exchanging two elements if they are out of order.
 */

public class ArraySorter {

    /**
     * Sorts an array of double values in ascending order using a simple sorting algorithm.
     * 
     * @param arr - An array of double values to be sorted.
     * @return - The sorted array in ascending order.
     */
    public double[] sortArray(double[] arr) {
        int n = arr.length; // Get the length of the array

        // Step 1: Use Selection Sort to sort the array in ascending order.
        for (int i = 0; i < n - 1; i++) { 
            // Outer loop: each iteration finds the next smallest element.
            for (int j = i + 1; j < n; j++) { 
                // Inner loop: compare the current element with the subsequent elements.
                if (arr[j] < arr[i]) {
                    // Swap elements if the next element is smaller.
                    double temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }

        // Step 2: Return the sorted array.
        return arr; 
    }
}
