package listofthings;

import java.util.List;

/**
 * 📚 ListManipulator.java
 * 
 * This class provides a method to manipulate a list of strings according to specific rules.
 * The list is modified based on its initial state: empty or non-empty.
 * 
 * 💡 Key Concepts:
 * - List Manipulation: Adding, removing, and updating list elements.
 * - Conditional Logic: Handling cases where the list becomes empty after modification.
 * - Dynamic Updating: Changing the contents of the list based on its current state.
 */

public class ListManipulator {

    /**
     * Manipulates a list of strings based on specific rules:
     * 1. If the list is empty, adds the word "first".
     * 2. If not empty, removes the last element.
     * 3. If the list becomes empty after removal, adds "first" and returns.
     * 4. Updates the new last element with a message indicating the list size.
     * 5. Adds "last" to the end of the list.
     * 6. Sets the first element to "first".
     * 
     * @param list - The list of strings to manipulate.
     * @return - The manipulated list.
     */
    public List<String> manipulateList(List<String> list) {
        // Step 1: If the list is empty, add "first" and return.
        if (list.isEmpty()) {
            list.add("first");
            return list;
        }

        // Step 2: Remove the last element from the list.
        list.remove(list.size() - 1);

        // Step 3: Check if the list became empty after removal.
        if (list.isEmpty()) {
            // Add "first" if the list is now empty.
            list.add("first");
            return list;
        }

        // Step 4: Update the new last element with the list size information.
        list.set(list.size() - 1, "The size of the list is " + list.size());

        // Step 5: Add "last" to the end of the list.
        list.add("last");

        // Step 6: Set the first element to "first" to ensure consistent formatting.
        list.set(0, "first");

        // Step 7: Return the manipulated list.
        return list;
    }
}
