package listofthings;

/**
 * 📚 ArrayAdder.java
 * 
 * This class provides a method to concatenate two integer arrays into a single array.
 * The result is a new array that contains all elements from the first array followed by all elements from the second array.
 * 
 * 💡 Key Concepts:
 * - Array Manipulation: Combining two arrays into one.
 * - Efficient Looping: Using separate loops for each array to fill the result.
 * - Zero-based Indexing: Properly calculating the target index in the result array.
 */

public class ArrayAdder {

    /**
     * Concatenates two arrays by combining their elements into a new array.
     * 
     * @param arr1 - The first integer array.
     * @param arr2 - The second integer array.
     * @return - A new array containing all elements from arr1 followed by elements from arr2.
     */
    public static int[] concatArrays(int[] arr1, int[] arr2) {

        // Step 1: Create a result array with the combined length of both input arrays.
        int[] result = new int[arr1.length + arr2.length];

        // Step 2: Copy elements from the first array (arr1) to the result array.
        // Use a for loop to iterate through each element in arr1.
        for (int i = 0; i < arr1.length; i++) {
            // Assign the current element from arr1 to the corresponding position in result.
            result[i] = arr1[i];
        }

        // Step 3: Copy elements from the second array (arr2) to the result array.
        // Use a for loop to iterate through each element in arr2.
        for (int i = 0; i < arr2.length; i++) {
            // Calculate the correct position in result by adding the length of arr1 to the current index.
            result[arr1.length + i] = arr2[i];
        }

        // Step 4: Return the concatenated result array.
        return result;
    }
}
