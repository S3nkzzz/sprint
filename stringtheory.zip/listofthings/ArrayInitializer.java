package listofthings;

/**
 * 📚 ArrayInitializer.java
 * 
 * This class provides a method to create and initialize an array of integers from 1 to a given maximum value.
 * The resulting array will contain consecutive integers starting from 1 up to the specified maximum.
 * 
 * 💡 Key Concepts:
 * - Array Initialization: Creating an array of integers.
 * - Iterative Filling: Using a loop to populate the array with consecutive numbers.
 * - Input Validation: Handling cases where the maximum value is less than 1.
 */

public class ArrayInitializer {

    /**
     * Creates an integer array filled with consecutive numbers from 1 to the specified maximum.
     * 
     * @param max - The maximum number to include in the array.
     * @return - An array containing integers from 1 to max, or an empty array if max < 1.
     */
    public int[] fillArray(int max) {

        // Step 1: Check for invalid input (if max is less than 1).
        if (max < 1) {
            // Return an empty array if the max value is invalid.
            return new int[0];
        }

        // Step 2: Create an array of size "max".
        int[] array = new int[max];

        // Step 3: Populate the array with consecutive integers starting from 1.
        for (int i = 0; i < max; i++) {
            // Assign the value (index + 1) to the current array position.
            array[i] = i + 1;
        }

        // Step 4: Return the filled array.
        return array;
    }
}
