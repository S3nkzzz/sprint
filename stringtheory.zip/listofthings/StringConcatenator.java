package listofthings;

/**
 * 📚 StringConcatenator.java
 * 
 * This class provides a method to concatenate a variable number of strings into a single result.
 * It uses the StringBuilder class for efficient concatenation, minimizing the number of intermediate strings created.
 * 
 * 💡 Key Concepts:
 * - Variable Arguments (Varargs): Using "String..." to accept a flexible number of strings.
 * - Efficient String Handling: Using StringBuilder for concatenation.
 * - Looping Through Arguments: Iterating through the provided strings using an enhanced for loop.
 */

public class StringConcatenator {

    /**
     * Concatenates a variable number of strings into a single combined string.
     * 
     * @param strings - A variable number of string arguments to be concatenated.
     * @return - The concatenated result as a single string.
     */
    public String concatenate(String... strings) {
        // Step 1: Create a StringBuilder for efficient concatenation.
        StringBuilder sb = new StringBuilder(); 

        // Step 2: Loop through each provided string and append it to the StringBuilder.
        for (String str : strings) { 
            sb.append(str); // Append the current string to the result.
        }

        // Step 3: Convert the accumulated result in StringBuilder to a final string.
        return sb.toString(); 
    }
}
