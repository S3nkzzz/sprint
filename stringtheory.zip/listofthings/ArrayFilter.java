package listofthings;

import java.util.ArrayList;
import java.util.List;

/**
 * 📚 ArrayFilter.java
 * 
 * This class provides a method to filter a 2D integer array based on the sum of its subarrays.
 * It returns only those subarrays whose sum is greater than or equal to the specified value.
 * 
 * 💡 Key Concepts:
 * - Filtering: Retaining only the subarrays that meet the sum condition.
 * - Dynamic Storage: Using an ArrayList to hold filtered subarrays temporarily.
 * - Conversion: Transforming a list of arrays back into a 2D array.
 */

public class ArrayFilter {

    /**
     * Filters the given 2D array by retaining only subarrays whose sum is greater than or equal to the specified value.
     * 
     * @param array - A 2D integer array containing subarrays to be filtered.
     * @param value - The threshold sum that a subarray must meet or exceed to be included.
     * @return - A filtered 2D array containing only the subarrays that satisfy the sum condition.
     */
    public int[][] filterBySum(int[][] array, int value) {
        // Step 1: Create a list to temporarily store the subarrays that meet the condition.
        List<int[]> resultList = new ArrayList<>(); 

        // Step 2: Iterate through each subarray in the given 2D array.
        for (int[] subArray : array) { 
            int sum = 0; // Initialize sum for the current subarray.

            // Step 3: Calculate the sum of the current subarray.
            for (int num : subArray) { 
                sum += num;
            }

            // Step 4: Check if the sum meets or exceeds the specified value.
            if (sum >= value) { 
                // If yes, add the subarray to the result list.
                resultList.add(subArray);
            }
        }

        // Step 5: Convert the result list back to a 2D array.
        int[][] result = new int[resultList.size()][];
        for (int i = 0; i < resultList.size(); i++) {
            // Get each subarray from the list and assign it to the result array.
            result[i] = resultList.get(i);
        }

        // Step 6: Return the filtered 2D array.
        return result; 
    }
}
