# 📚 Group Projects

## 📝 Description:

This folder contains collaborative projects developed as part of team tasks during the Selection Sprint at kood/Jõhvi. Each project showcases teamwork, problem-solving, and advanced Java development skills. 🚀

---

## 💡 Skills Acquired:

* Collaborating in a team environment.
* Developing robust and scalable Java applications.
* Implementing encryption algorithms and data processing tools.
* Writing modular, team-oriented code.
* Utilizing version control and project documentation effectively.

---

## 📂 Project List and Features:

1. **Notes Tool** (Danila Kargajev, Hans Otto Pool, Jevgeni Tsernokozov):

   * Command-line tool for managing notes.
   * Supports adding, deleting, and viewing notes within collections.
   * Implements file handling and persistent storage.
   * User-friendly CLI and error handling.

2. **Cypher Tool** (Lev Arhipov, Arseni Denissov, Jevgeni Tsernokozov):

   * Command-line encryption and decryption tool.
   * Supports multiple encryption methods: ROT13, Atbash, and custom.
   * Input validation and robust data handling.
   * Interactive interface for selecting options and processing text.

---

## 🚀 How to Run:

1. Open a terminal in the Group Projects directory.
2. Compile the desired Java file:

   ```bash
   javac FileName.java
   ```
3. Run the compiled file:

   ```bash
   java FileName
   ```

### Usage Example:

```bash
javac NotesTool.java
java NotesTool
```

---

## 🗝️ Key Concepts Covered:

* Team Collaboration: Working with multiple developers
* Encryption Techniques: Implementing ROT13, Atbash, and custom methods
* Command-Line Utilities: Building interactive tools
* Data Storage: Persistent note management

Happy Coding! 😊🚀
