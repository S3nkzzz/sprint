public class Rot13 {

    // Rot13 encryption/decryption method
    public static String encrypt(String s) {
        char[] characters = s.toCharArray();
        for (int i = 0; i < characters.length; i++) {
            // if character is letter A-M or a-m, then replace it with the character 13 steps forward
            if ((int) characters[i] >= 65 && (int) characters[i] <= 77 || (int) characters[i] >= 97 && (int) characters[i] <= 109) {
                characters[i] += 13;
            // if character is letter N-Z or n-z, then replace it with the character 13 steps backward
            } else if ((int) characters[i] >= 78 && (int) characters[i] <= 90 || (int) characters[i] >= 110 && (int) characters[i] <= 122) {
                characters[i] -= 13;
            }
            // otherwise don't change the character
        }
        return String.valueOf(characters);
    }

}