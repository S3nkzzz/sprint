    
    /**
 * 📚 CypherTool.java
 *
 * This class serves as the main entry point for a command-line encryption and decryption tool.
 * It supports multiple encryption algorithms: ROT13, Atbash, and ASCII-based encryption.
 * The tool allows the user to input a message and choose an encryption or decryption method. 🚀
 *
 * 💡 Key Concepts:
 * - Modular Design: Separate methods for each encryption algorithm.
 * - Command-Line Interface (CLI): Uses the main method as an entry point.
 * - Method Delegation: Calls specific methods from other classes to perform encryption or decryption.
 */




public class CypherTool {

    /**
     * The main method is the entry point of the CypherTool application.
     * It starts by calling the method to get user input.
     *
     * @param args - Command line arguments (not used in this application).
     */
    public static void main(String[] args) {
        // Start the application by getting user input.
        getInput();
    }

    /**
     * Calls the input handler to prompt the user for input.
     * Uses an external method from the Input class to simplify the code structure.
     */
    public static void getInput() {
        // Delegate to the Input class to handle user input.
        Input.getInput();
    }

    /**
     * Encrypts a string using the ROT13 algorithm.
     *
     * @param s - The input string to be encrypted.
     * @return - The encrypted string using ROT13.
     */
    public static String encryptRot13(String s) {
        // Call the ROT13 encryption method from the Rot13 class.
        return Rot13.encrypt(s);
    }

    /**
     * Decrypts a string using the ROT13 algorithm.
     *
     * @param s - The input string to be decrypted.
     * @return - The decrypted string using ROT13 (same as encryption for ROT13).
     */
    public static String decryptRot13(String s) {
        // ROT13 encryption and decryption are the same operation.
        return Rot13.encrypt(s);
    }

    /**
     * Encrypts a string using the Atbash algorithm.
     *
     * @param s - The input string to be encrypted.
     * @return - The encrypted string using Atbash.
     */
    public static String encryptAtbash(String s) {
        // Call the Atbash encryption method from the Atbash class.
        return Atbash.encrypt(s);
    }

    /**
     * Decrypts a string using the Atbash algorithm.
     *
     * @param s - The input string to be decrypted.
     * @return - The decrypted string using Atbash (same as encryption for Atbash).
     */
    public static String decryptAtbash(String s) {
        // Atbash encryption and decryption are the same operation.
        return Atbash.encrypt(s);
    }

    /**
     * Encrypts a string using the ASCII-based encryption method.
     *
     * @param s - The input string to be encrypted.
     * @return - The encrypted string using the ASCII algorithm.
     */
    public static String encryptASCII(String s) {
        // Call the ASCII encryption method from the ASCII class.
        return ASCII.encrypt(s);
    }

    /**
     * Decrypts a string using the ASCII-based decryption method.
     *
     * @param s - The input string to be decrypted.
     * @return - The decrypted string using the ASCII algorithm.
     */
    public static String decryptASCII(String s) {
        // Call the ASCII decryption method from the ASCII class.
        return ASCII.decrypt(s);
    }
}
