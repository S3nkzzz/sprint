
public class Atbash { // atbash cryption method
    public static String encrypt(String text) {
        StringBuilder result = new StringBuilder(); // To build the final encrypted string

        for (char ch : text.toCharArray()) { // Loop through each character in the input string 
            if (ch >= 'A' && ch <= 'Z') {
                // If the character is an uppercase letter, apply Atbash formula 
                result.append((char) ('Z' - (ch - 'A')));
            } else if (ch >= 'a' && ch <= 'z') {
                // If the character is a lowercase letter, apply Atbash formula 
                result.append((char) ('z' - (ch - 'a')));
            } else {
                // If the character is not a letter
                result.append(ch);
            }
        }

        return result.toString(); // Return the encrypted string
    }
}