
import java.util.Scanner;





/**
 * 📚 Input.java
 *
 * This class handles user input for the Cypher tool. It prompts the user to select an operation 
 * (Encrypt or Decrypt), choose a cipher method (Rot13, Atbash, ASCII), and enter a message to process.
 * The program also supports the "exit" command to terminate the input loop. 🚀
 *
 * 💡 Key Concepts:
 * - User Input Handling: Uses Scanner to read user input.
 * - Input Validation: Ensures the user provides valid choices.
 * - Loop Control: Uses a while loop for continuous input until "exit" is entered.
 * - Encryption/Decryption: Calls methods from CypherTool based on user choices.
 */

public class Input {

    /**
     * Handles user input, validates it, and calls the appropriate encryption or decryption method.
     */
    @SuppressWarnings("UnnecessaryContinue")
    public static void getInput() {
        // Create a Scanner object to read user input from the console
        Scanner scanner = new Scanner(System.in);

        String operation = "";  // Stores the chosen operation (encrypt/decrypt)
        String cypher = "";     // Stores the chosen cipher (Rot13, Atbash, ASCII)
        String message = "";    // Stores the user-entered message to encrypt or decrypt

        // Welcome message
        System.out.println("\nWelcome to the Cypher tool!\n");

        // Infinite loop to continuously prompt for input until "exit" is chosen
        while (true) {
            // Prompt for operation choice
            System.out.println("Select operation:\n1. Encrypt\n2. Decrypt");
            operation = scanner.nextLine();

            // Check if the user wants to exit
            if (operation.equals("exit")) {
                break;
            } 
            // Validate operation choice
            else if (!operation.equals("1") && !operation.equals("2")) {
                System.out.println("\nInvalid input! Possible inputs: 1, 2.\n");
                continue;
            }

            // Prompt for cipher choice
            System.out.println("\nSelect cypher:\n1. Rot13\n2. Atbash\n3. ASCII");
            cypher = scanner.nextLine();

            // Check if the user wants to exit
            if (cypher.equals("exit")) {
                break;
            } 
            // Validate cipher choice
            else if (!cypher.equals("1") && !cypher.equals("2") && !cypher.equals("3")) {
                System.out.println("\nInvalid input! Possible inputs: 1, 2, 3\n");
                continue;
            }

            // Prompt for the message to encrypt or decrypt
            System.out.println("\nEnter message:");
            message = scanner.nextLine().trim();

            // Validate the message (non-empty and not just spaces)
            if (message.isEmpty()) {
                System.out.println("Empty message or message consisting only of spaces is not allowed.");
                continue;
            } else {
                break;
            }
        }

        // Process the message if it is not empty
        if (!message.isEmpty()) {
            // Encrypt or decrypt based on the selected cipher and operation
            if (cypher.equals("1")) {
                System.out.println("\nEncrypted message (Rot13):\n" + CypherTool.encryptRot13(message));
            } else if (cypher.equals("2")) {
                System.out.println("\nEncrypted message (Atbash):\n" + CypherTool.encryptAtbash(message));
            } 
            // Check for ASCII encryption or decryption
            else if (cypher.equals("3") && operation.equals("1")) {
                System.out.println("\nEncrypted message (ASCII):\n" + CypherTool.encryptASCII(message));
            } else if (cypher.equals("3") && operation.equals("2")) {
                System.out.println("\nDecrypted message (ASCII):\n" + CypherTool.decryptASCII(message));
            }
        }
    }
}
