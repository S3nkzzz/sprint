package cyphertool;

public class Main {

    public static void main(String[] args) {
        CypherTool.main(args);
    }
}