package firstgradejava;

/**
 * 📚 SignPost.java
 *
 * This class calculates the area of a rectangular signboard based on a given text input.
 * The area is calculated as the product of the maximum line width and the number of lines (height).
 * 
 * 💡 Key Concepts:
 * - String Manipulation: Splitting a text into lines.
 * - Array Handling: Working with string arrays to calculate dimensions.
 * - Mathematical Calculation: Area = max width * height.
 */

public class SignPost {

    /**
     * Calculates the area of a signboard based on the given multiline text input.
     *
     * @param input - A string containing multiple lines separated by newline characters.
     * @return - The calculated area as an integer.
     */
    public int getArea(String input) {

        // Split the input string into an array of lines using the newline character.
        String[] lines = input.split("\n");

        // Variable to keep track of the maximum line width.
        int maxWidth = 0;

        // Iterate through each line to find the longest one.
        for (String line : lines) {
            // Update maxWidth if the current line length is greater.
            if (line.length() > maxWidth) {
                maxWidth = line.length();
            }
        }

        // Calculate the height as the number of lines.
        int height = lines.length;

        // Return the calculated area (width * height).
        return maxWidth * height;
    }
}
