package firstgradejava;

/**
 * 📚 Calculator.java
 *
 * This class provides a simple method to perform addition of two integers.
 * The method takes two integers as input and returns their sum. 🚀
 *
 * 💡 Key Concepts:
 * - Arithmetic Operation: Addition of integers.
 * - Simple Calculation: Directly returns the sum of the two numbers.
 * - Method Simplicity: Designed for basic addition tasks.
 */

public class Calculator {

    /**
     * Adds two integer values and returns the result.
     *
     * @param a - The first integer to be added.
     * @param b - The second integer to be added.
     * @return - The sum of the two integers.
     */
    public int add(int a, int b) {

        // Return the sum of the two integers.
        return a + b;
    }
}
