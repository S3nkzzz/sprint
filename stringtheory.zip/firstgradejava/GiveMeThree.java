package firstgradejava;

/**
 * 📚 GiveMeThree.java
 *
 * This simple class provides a method to return the number three.
 * It serves as a basic example of a method that returns a fixed integer value. 🚀
 *
 * 💡 Key Concepts:
 * - Method Definition: Creating a simple method that returns a constant value.
 * - Return Statement: Using the `return` keyword to output a specific integer.
 */

public class GiveMeThree {

    /**
     * Returns the integer value 3.
     *
     * @return - The fixed integer value 3.
     */
    public int returnThree() {

        // Directly return the integer 3.
        return 3;
    }
}
