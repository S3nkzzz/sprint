package firstgradejava;

/**
 * 📚 HelloSprinter.java
 *
 * This simple class prints a welcome message to the console.
 * It demonstrates the use of the main method as the entry point of a Java program. 🚀
 *
 * 💡 Key Concepts:
 * - Main Method: The starting point of any Java application.
 * - Console Output: Using `System.out.println()` to print messages.
 */

public class HelloSprinter {

    /**
     * The main method is the entry point of the Java application.
     * It prints a greeting message to the console.
     *
     * @param args - Command line arguments (not used in this program).
     */
    public static void main(String[] args) {

        // Print a simple welcome message to the console.
        System.out.println("Hello, Sprinter!");
    }
}
