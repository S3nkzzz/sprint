package firstgradejava;

/**
 * 📚 ReverseLetter.java
 *
 * This class provides a method to find the reverse of a given lowercase letter in the English alphabet.
 * The reverse letter is calculated based on the position in the alphabet:
 * - 'a' becomes 'z'
 * - 'b' becomes 'y'
 * - 'c' becomes 'x'
 * - and so on.
 *
 * 💡 Key Concepts:
 * - ASCII Arithmetic: Calculating the reverse letter using ASCII values.
 * - Character Manipulation: Using mathematical transformations to reverse alphabet order.
 */

public class ReverseLetter {

    /**
     * Reverses the position of the given lowercase letter in the alphabet.
     *
     * @param letter - The lowercase letter ('a' to 'z') to be reversed.
     * @return - The reversed letter from the opposite side of the alphabet.
     */
    public char reverseLetter(char letter) {

        // Calculate the reversed letter using ASCII arithmetic.
        // Subtract the difference between the input letter and 'a' from 'z'.
        return (char) ('z' - (letter - 'a'));
    }
}
