package firstgradejava;

/**
 * 📚 StrConcat.java
 *
 * This class provides a method to concatenate two strings with a specified delimiter in between.
 * The result is a single combined string separated by the given character. 🚀
 *
 * 💡 Key Concepts:
 * - String Concatenation: Merging two strings with a delimiter.
 * - Character Usage: Inserting a character between strings.
 * - Return Statement: Producing the concatenated result.
 */

public class StrConcat {

    /**
     * Concatenates two strings with a specified delimiter between them.
     *
     * @param str1 - The first string to be concatenated.
     * @param str2 - The second string to be concatenated.
     * @param delimiter - The character used to separate the two strings.
     * @return - A new string in the format: str1 + delimiter + str2.
     */
    public String concatWithDelimiter(String str1, String str2, char delimiter) {

        // Concatenate the first string, delimiter, and second string.
        return str1 + delimiter + str2;
    }
}
