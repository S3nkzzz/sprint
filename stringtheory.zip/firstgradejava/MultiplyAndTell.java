package firstgradejava;

/**
 * 📚 MultiplyAndTell.java
 *
 * This class provides a method to multiply a given integer by 2 and return the result as a formatted string.
 * The result is presented as a concatenated message. 🚀
 *
 * 💡 Key Concepts:
 * - String Concatenation: Combining text and numbers into one string.
 * - Arithmetic Operation: Multiplication of an integer.
 * - Return Statement: Returning a formatted message.
 */

public class MultiplyAndTell {

    /**
     * Multiplies the given number by 2 and returns the result as a formatted string.
     *
     * @param number - The integer value to be multiplied.
     * @return - A string containing the result in the format: "The result is [number * 2]".
     */
    public String printMult2Concat(int number) {

        // Multiply the input number by 2 and concatenate the result with a message.
        return "The result is " + (number * 2);
    }
}
