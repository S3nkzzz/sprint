package firstgradejava;

/**
 * 📚 AsciiAdder.java
 *
 * This class provides a method to shift a given character by a specified number of ASCII positions.
 * The result is the character that appears after adding the shift value to the ASCII code of the input character. 🚀
 *
 * 💡 Key Concepts:
 * - ASCII Encoding: Characters are represented as numerical codes.
 * - Type Casting: Converting the result of integer addition back to a character.
 * - Character Manipulation: Shifting a character by a given amount.
 */

public class AsciiAdder {

    /**
     * Adds a specified ASCII shift to the given character.
     *
     * @param input - The character to be shifted.
     * @param shift - The number of ASCII positions to shift.
     * @return - The new character obtained after shifting.
     */
    public char addAscii(char input, int shift) {

        // Add the shift value to the ASCII code of the input character.
        // Use (char) to convert the integer result back to a character.
        return (char) (input + shift);
    }
}
