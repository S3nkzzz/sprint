package firstgradejava;

/**
 * 📚 AverageCalculator.java
 *
 * This class provides a method to calculate the average of three floating-point numbers.
 * The average is obtained by summing the three numbers and dividing the result by three. 🚀
 *
 * 💡 Key Concepts:
 * - Arithmetic Operations: Addition and division.
 * - Floating-Point Precision: The result is a floating-point number.
 * - Simple Mathematical Formula: (num1 + num2 + num3) / 3
 */

public class AverageCalculator {

    /**
     * Calculates the average of three floating-point numbers.
     *
     * @param num1 - The first floating-point number.
     * @param num2 - The second floating-point number.
     * @param num3 - The third floating-point number.
     * @return - The average of the three numbers as a float.
     */
    public float calculateAverage(float num1, float num2, float num3) {

        // Sum the three numbers and divide by three to get the average.
        return (num1 + num2 + num3) / 3;
    }
}
