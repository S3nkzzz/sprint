package firstgradejava;

/**
 * 📚 FloatMinusInt.java
 *
 * This class provides methods to perform subtraction between a floating-point number (double) and an integer.
 * The subtraction result can be returned either as a double or as an integer, depending on the method used. 🚀
 *
 * 💡 Key Concepts:
 * - Arithmetic Operation: Subtraction between different numeric types (double and int).
 * - Type Casting: Converting a double to an int when necessary.
 * - Precision Loss: Understanding the difference between floating-point and integer results.
 */

public class FloatMinusInt {

    /**
     * Subtracts an integer from a double and returns the result as a double.
     *
     * @param floating - The floating-point number (double) to subtract from.
     * @param integer - The integer value to be subtracted.
     * @return - The difference as a double.
     */
    public double subtractIntFromDoubleAndReturnDouble(double floating, int integer) {

        // Subtract the integer from the double, maintaining double precision.
        return floating - integer;
    }

    /**
     * Subtracts an integer from a double and returns the result as an integer.
     *
     * @param floating - The floating-point number (double) to subtract from.
     * @param integer - The integer value to be subtracted.
     * @return - The difference as an integer after casting.
     */
    public int subtractIntFromDoubleAndReturnInt(double floating, int integer) {

        // Convert the double to an integer and then perform subtraction.
        // This may cause precision loss since the decimal part is truncated.
        return (int) floating - integer;
    }
}
