
# 📚 First Grade Java

**Description:**  
This folder contains basic Java programs developed during the first stage of the Selection Sprint at kood/Jõhvi. 
The tasks are designed to build a solid foundation in Java syntax, basic operations, and logic implementation. 🚀

---

### 💡 Skills Acquired:  
- 📑 Understanding basic Java syntax and structure.  
- ➕ Performing basic arithmetic operations.  
- 💾 Working with variables and data types.  
- 🖥️ Simple input and output handling using `System.out.println()` and `Scanner`.  
- 🧠 Basic problem-solving techniques.  
- 🔁 Implementing basic loops and conditional statements (`for`, `while`, `if-else`).  
- ✂️ String manipulation and concatenation.  
- 📊 Calculating averages and working with ASCII values.  
- 🔢 Understanding the difference between float and integer operations.  

---

### 📂 Program List and Features:

1. **🔠 AsciiAdder:**  
   - Adds ASCII values of characters and prints the result.  
   - Demonstrates usage of `char` to `int` conversion.  
   - Uses `System.out.println()` for output.  

2. **📏 AverageCalculator:**  
   - Calculates the average of given numbers.  
   - Uses basic arithmetic and floating-point division.  
   - Demonstrates type casting and formatting the result.  

3. **🧮 Calculator:**  
   - A simple arithmetic calculator performing addition, subtraction, multiplication, and division.  
   - Uses `Scanner` for input and `if-else` for operation choice.  

4. **🔄 FloatMinusInt:**  
   - Demonstrates subtraction between float and integer values.  
   - Highlights data type compatibility and precision loss.  

5. **🎯 GiveMeThree:**  
   - Simple method that always returns the number 3.  
   - Demonstrates method definition and return statement.  

6. **👋 HelloSprinter:**  
   - Prints a greeting message to the console.  
   - Uses `System.out.println()` for simple output.  

7. **✖️ MultiplyAndTell:**  
   - Multiplies two numbers and prints the result.  
   - Uses basic multiplication and formatted output.  

8. **🔁 ReverseLetter:**  
   - Reverses the order of letters in a given word.  
   - Demonstrates `StringBuilder` and its reverse method.  

9. **🪧 SignPost:**  
   - Prints a directional sign message based on user input.  
   - Uses `switch-case` for conditional logic.  

10. **🔗 StrConcat:**  
    - Concatenates multiple strings into one.  
    - Demonstrates string concatenation using `+` operator.  

---

### 🛠️ How to Run:
1. Open a terminal in the **First Grade Java** directory.  
2. Compile the desired Java file:  
   ```
   javac FileName.java
   ```  
3. Run the compiled file:  
   ```
   java FileName
   ```  

**Usage Example:**  
```
javac HelloSprinter.java  
java HelloSprinter  
```  

---

### 📑 Key Concepts Covered:
- **Data Types:** int, float, double, char, String  
- **Basic Operators:** +, -, *, /  
- **Input and Output:** Using `Scanner` and `System.out.println()`  
- **Conditional Statements:** `if-else`, `switch-case`  
- **Loops:** `for`, `while`  
- **String Manipulation:** Concatenation, reverse  
- **Methods:** Defining simple methods with return types  

Happy Coding! 😊🚀
